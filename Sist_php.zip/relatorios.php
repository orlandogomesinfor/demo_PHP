<?php header('Content-Type: text/html; charset=ISO-8859-1'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
<!--
#apDiv1 {
	position:absolute;
	left:86px;
	top:152px;
	width:836px;
	height:237px;
	z-index:1;
}
#apDiv2 {
	position:absolute;
	left:323px;
	top:441px;
	width:360px;
	height:85px;
	z-index:2;
}
.style1 {
	color: #0000CC;
	font-style: italic;
}
-->
</style>
</head>
<body>
      <?php require_once('cabecalho.php'); ?>
<p align="center">
<a href="cadastro.php?pagina=link1" class="link1"><span>Orcamentos</span></a> | 
<a href="cadastro.php?pagina=link2" class="link2"><span>Financeiro</span></a> |
<a href="cadastro.php?pagina=link3" class="link3"><span>Estoque</span></a> | 
<a href="cadastro.php?pagina=link4" class="link4"><span>Cadastro - Gerenciais</span></a>
<!-- Transportadora |
<a href="cadastro.php?pagina=link6" class="link6"><span>CFOP</span></a>
 | <a href="cadastro.php?pagina=link7">UF-ICMS</a-->  </p>
<!--div id="caixa" -->
      <?php

      if($_GET['pagina'] == 'link1') {
	    include "cliente/mostra_dados.php";         }
      elseif($_GET['pagina'] == 'link2')  {
        include "repre/mostra_dados.php";         }
      elseif($_GET['pagina'] == 'link3')  {
 	    include "material/mostra_dados.php";         } 
      elseif($_GET['pagina'] == 'link4')   {
	    include "grupo/mostra_grupo.php"; } 
      elseif($_GET['pagina'] == 'link5')   {
	    include "pag/link5.php"; } 
	  elseif($_GET['pagina'] == 'link6')   {
        include "cfop/mostra_cfop.php"; } 
      elseif($_GET['pagina'] == 'link7')   {
	    include "uf_icms/mostra_dados.php"; } 
      elseif($_GET['pagina'] == 'link10')   { 
	    include "manu_001.php"; } //manu_001.php cadastro materiais   }  
      elseif($_GET['pagina'] == 'link11')   { 
	    include "manu_002.php";  } //manu_002 cadastro ICMS

      else  { 
	    include "pag/link1.php";         }
      ?>   
   </div> 
<?php include('rodape.php'); ?>
</body>
</html>

