<?php require_once('Connections/cn_central.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO tabicms (SIGLA, ESTADO, PERCENTUAL, MARGEM, PERC_MARG, CALCSIT) VALUES (%s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['SIGLA'], "text"),
                       GetSQLValueString($_POST['ESTADO'], "text"),
                       GetSQLValueString($_POST['PERCENTUAL'], "double"),
                       GetSQLValueString($_POST['MARGEM'], "double"),
                       GetSQLValueString($_POST['PERC_MARG'], "double"),
                       GetSQLValueString($_POST['CALCSIT'], "text"));

  mysql_select_db($database_cn_central, $cn_central);
  $Result1 = mysql_query($insertSQL, $cn_central) or die(mysql_error());

  $insertGoTo = "sucesso_icms.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style2 {color: #000000}
-->
</style>
</head>

<body>
<h2 align="center" class="style2">Cadastro de ICMS</h2>
<table width="200" border="1" align="center">
  <tr>
    <td background="inicio.php" class="style2"><a href="inicio.php">Página inicial</a> | Finalizar</td>
  </tr>
</table>
<p class="style2">&nbsp;</p>

<form action="<?php echo $editFormAction; ?>" method="post" name="form1" id="form1">
  <table align="center">
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">UF</td>
      <td><input name="SIGLA" type="text" value="" size="4" maxlength="2" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">ESTADO:</td>
      <td><input type="text" name="ESTADO" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">PERCENTUAL:</td>
      <td><input name="PERCENTUAL" type="text" value="" size="5" maxlength="5" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">MARGEM:</td>
      <td><input name="MARGEM" type="text" value="" size="5" maxlength="5" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">% da Margem</td>
      <td><input name="PERC_MARG" type="text" value="" size="5" maxlength="5" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Calcula Sit. Tributaria</td>
      <td><input name="CALCSIT" type="text" value="" size="2" maxlength="1" /></td>
    </tr>
    <tr valign="baseline">
      <td colspan="2" align="right" nowrap="nowrap"><div align="center">
        <input type="submit" value="Salvar" />
      </div></td>
    </tr>
  </table>
  <input type="hidden" name="MM_insert" value="form1" />
</form>
<p>&nbsp;</p>
</body>
</html>
