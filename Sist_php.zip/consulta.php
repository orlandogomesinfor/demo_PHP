<html>
<title>Consulta Dados</title>
<body background="imagens/fundo_azul.png">
<H1 ALIGN="CENTER"><font color="#0000CC">CADASTRO DE PESSOAS F�SICAS</font></H1>
<hr align="center">
<div align="center"><font color="#0066CC" size="5">M&oacute;dulo Consulta</font></div>
<BR>
<?php
//net
//$conexao="mysql18.redehost.com.br,3306";
$conexao=mysql_connect("mysql18.redehost.com.br","usuariorcentral","usuariocentral");
mysql_select_db("central1",$conexao);
$consulta = "select*from test_prefixmaterial limit 1,20";

//local
//$conexao=mysql_connect("localhost","root","");
//mysql_select_db("central",$conexao);
//$consulta = "select*from material limit 1,2";
$resultado = mysql_query ($consulta,$conexao);
echo "<table>"; // border='1' align='center'>";
echo "<tr><td><b>Codigo</b></td><td><b>Nome</b><td><b>Bairro</b><td><b>Email</b><tr>";
while ($linha=mysql_fetch_row($resultado)) {

printf("<tr><td>$linha[3]</td>");
printf("<td>$linha[0]</td>");
printf("<td>$linha[1]</td>");
printf("<td>$linha[2]</td></tr>");
} 
echo"</table>\n";
?>

<p>&nbsp;</p><p>&nbsp;</p>
<p align="right"><a href="inicio.php">Voltar</a></p>
</body>
</html>
