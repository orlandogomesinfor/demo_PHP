<?php require_once('Connections/conexao.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_conexao, $conexao);
$query_rs_requis = "SELECT * FROM test_prefixrequis ORDER BY test_prefixrequis.NUMREQ";
$rs_requis = mysql_query($query_rs_requis, $conexao) or die(mysql_error());
$row_rs_requis = mysql_fetch_assoc($rs_requis);
$totalRows_rs_requis = mysql_num_rows($rs_requis);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<h2 align="center">Relatório Requisição</h2>
<p>&nbsp;</p>
<table width="200" border="1">
  <tr>
    <td>Requisição</td>
    <td>Data</td>
    <td>Cliente</td>
    <td>Representante</td>
    <td>UF</td>
    <td>Faturada</td>
  </tr>
  <?php do { ?>
    <tr>
      <td><?php echo $row_rs_requis['NUMREQ']; ?></td>
      <td><?php echo $row_rs_requis['DATREQ']; ?></td>
      <td><?php echo $row_rs_requis['CODCLI']; ?></td>
      <td><?php echo $row_rs_requis['CODREP']; ?></td>
      <td><?php echo $row_rs_requis['SIGLA']; ?></td>
      <td><?php echo $row_rs_requis['FATURADA']; ?></td>
    </tr>
    <?php } while ($row_rs_requis = mysql_fetch_assoc($rs_requis)); ?>
</table>
<p>&nbsp;</p>
</body>
</html>
<?php
mysql_free_result($rs_requis);
?>
