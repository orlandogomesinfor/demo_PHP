<?php
// mysql_connect    //conexao mysql 5.0
// mysql_select_db  // seleciona banco de dados 5.0
// $conexao=mysql_connect("localhost","root",""); conecta ao servidor mysql 4
// mysql_select_db("loja",$conexao); seleciona bando de dados 
//$consulta ="select*from cliente1";
//$resultado = mysql_query ($consulta,$conexao) // mysql 4
//mysql_query ($exclui,$conexao) or die ("Ocorreu algum erro!!!"); // opercao mysql 4

$bancox='central1';
$tabelax='test_prefixmaterial';
$conexao = mysql_connect ("mysql18.redehost.com.br","usuariorcentral","usuariocentral");

if (!$conexao) {
	die('Conexao nao Efeutada Falha: ' . mysql_error());  }

//Seleciona banco de dados

$banco_ok = mysql_select_db($bancox,$conexao);  // mysql 5.0 

if (!$banco_ok) {

	 die ('Erro na abertura de banco de dados: ' . mysql_error());   }

//recebe posicao de registro
$quem=$_GET['quem'];
$exclui = "delete from $tabelax where id='$quem'";
echo "<center>"; 
$resux=mysql_query ($exclui,$conexao);
    if ($resux==1) {
      echo "Registro excluido com sucesso"; 
	 }
	 else 	 {
	  echo "Erro!!!, registro n�o pode ser excluido.";	 }

   echo "<br><a href='../cadastro.php'><span>Tela de Cadastro Geral</span></a></center> | ";
   echo "<A HREF='../cadastro.php?pagina=link3' class='link3''>Exibe consulta</A><BR<BR></center>";
   include('../rodape.php'); 
?>

