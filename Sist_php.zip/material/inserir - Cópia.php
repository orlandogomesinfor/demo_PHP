<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php require_once('../Connections/conexao.php'); ?>

<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO test_prefixmaterial (CODMAT, DESCRICAO, DESCRICA2, UNIDADE, VUNIT, VUNIT2, VUNIT3, VUNIT4, VUNIT5, VUNIT6, `DATA`, DIAS_COMP, ESTMIN, CODLT, IPI, PESOBR, VLMINIMO, EAN) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['CODMAT'], "text"),
                       GetSQLValueString($_POST['DESCRICAO'], "text"),
                       GetSQLValueString($_POST['DESCRICA2'], "text"),
                       GetSQLValueString($_POST['UNIDADE'], "text"),
                       GetSQLValueString($_POST['VUNIT'], "double"),
                       GetSQLValueString($_POST['VUNIT2'], "double"),
                       GetSQLValueString($_POST['VUNIT3'], "double"),
                       GetSQLValueString($_POST['VUNIT4'], "double"),
                       GetSQLValueString($_POST['VUNIT5'], "double"),
                       GetSQLValueString($_POST['VUNIT6'], "double"),
                       GetSQLValueString($_POST['DATA'], "date"),
                       GetSQLValueString($_POST['DIAS_COMP'], "int"),
                       GetSQLValueString($_POST['ESTMIN'], "double"),
                       GetSQLValueString($_POST['CODLT'], "text"),
                       GetSQLValueString($_POST['IPI'], "double"),
                       GetSQLValueString($_POST['PESOBR'], "double"),
                       GetSQLValueString($_POST['VLMINIMO'], "double"),
                       GetSQLValueString($_POST['EAN'], "text"));

  mysql_select_db($database_conexao, $conexao);
  $Result1 = mysql_query($insertSQL, $conexao) or die(mysql_error());

  $insertGoTo = "cadastro_sucesso.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}


if (!function_exists("GetSQLValueString")) {

function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 

{

  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;



  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);



  switch ($theType) {

    case "text":

      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";

      break;    

    case "long":

    case "int":

      $theValue = ($theValue != "") ? intval($theValue) : "NULL";

      break;

    case "double":

      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";

      break;

    case "date":

      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";

      break;

    case "defined":

      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;

      break;

  }

  return $theValue;

}

}



$editFormAction = $_SERVER['PHP_SELF'];

if (isset($_SERVER['QUERY_STRING'])) {

  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);

}



if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {

  $insertSQL = sprintf("INSERT INTO test_prefixnfopera (CODOPE, OPERACAO, TIPO, ESTOQUE, OPEABRE) VALUES (%s, %s, %s, %s, %s)",

                       GetSQLValueString($_POST['CODOPE'], "int"),

                       GetSQLValueString($_POST['OPERACAO'], "text"),

                       GetSQLValueString($_POST['TIPO'], "text"),

                       GetSQLValueString($_POST['ESTOQUE'], "text"),

                       GetSQLValueString($_POST['OPEABRE'], "text"));



  mysql_select_db($database_conexao, $conexao);

  $Result1 = mysql_query($insertSQL, $conexao) or die(mysql_error());



  $insertGoTo = "cadastro_sucesso.php";

  if (isset($_SERVER['QUERY_STRING'])) {

    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";

    $insertGoTo .= $_SERVER['QUERY_STRING'];

  }

  header(sprintf("Location: %s", $insertGoTo));

}

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Untitled Document</title>

</head>



<body>

<?php include('../cabecalho.php'); ?>

<h2 align="center">Cadastro de Produtos</h2>

<p align="center"><a href="../cadastro.php">Cadastro Geral de Tabelas </a> | 

<?php echo "<a href='../cadastro.php?pagina=link3' class='link3'><span>Exibir consulta</span></a></center>"; ?></p>



<p>&nbsp;</p>


<form action="<?php echo $editFormAction; ?>" method="post" name="form1" id="form1">
  <table width="683" border="0" align="center" bgcolor="#FFFFCC">
    <tr>
      <td width="88">Codigo:</td>
      <td width="275"><input name="CODMAT" type="text" value="" size="12" maxlength="12" /></td>
      <td width="10">&nbsp;</td>
      <td width="133">Dt. Cadastro:</td>
      <td width="143"><input type="text" name="DATA" value="" size="16" /></td>
    </tr>
    <tr>
      <td>Descrição:</td>
      <td><input name="DESCRICAO" type="text" value="" size="40" maxlength="40" /></td>
      <td>&nbsp;</td>
      <td>Codigo Letra:</td>
      <td><input type="text" name="CODLT" value="" size="5" /></td>
    </tr>
    <tr>
      <td>Descrição2:</td>
      <td><input type="text" name="DESCRICA2" value="" size="40" /></td>
      <td>&nbsp;</td>
      <td>EAN:</td>
      <td><input type="text" name="EAN" value="" size="20" /></td>
    </tr>
    <tr>
      <td>Unidade:</td>
      <td><input type="text" name="UNIDADE" value="" size="40" /></td>
      <td>&nbsp;</td>
      <td>Peso Br.:</td>
      <td><input type="text" name="PESOBR" value="" size="10" /></td>
    </tr>
    <tr>
      <td>Vl. Unit.</td>
      <td><input type="text" name="VUNIT" value="" size="20" /></td>
      <td>&nbsp;</td>
      <td>Valor Min.:</td>
      <td><input type="text" name="VLMINIMO" value="" size="14" /></td>
    </tr>
    <tr>
      <td>Dias Compra:</td>
      <td><input type="text" name="DIAS_COMP" value="" size="5" /></td>
      <td>&nbsp;</td>
      <td>Estoque Min.:</td>
      <td><input type="text" name="ESTMIN" value="" size="8" /></td>
    </tr>
    <tr>
      <td>IPI:</td>
      <td><input type="text" name="IPI" value="" size="6" /></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
  </table>
<hr />

  <table align="center" bgcolor="#FFFFCC">
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Vl Unit2:</td>
      <td><input type="text" name="VUNIT2" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Vl Unit3:</td>
      <td><input type="text" name="VUNIT3" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Vl. Unit4:</td>
      <td><input type="text" name="VUNIT4" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Vl. Unit5:</td>
      <td><input type="text" name="VUNIT5" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Vl. Unit7:</td>
      <td><input type="text" name="VUNIT6" value="" size="32" /></td>
    </tr>
    
    <tr valign="baseline">
      <td colspan="2" align="right" nowrap="nowrap"><div align="center">
        <input type="submit" value="Inserir" />
      </div></td>
    </tr>
  </table>
  <input type="hidden" name="MM_insert" value="form1" />
</form>
<p>&nbsp;</p>
</body>

</html>



</body>

</html>

