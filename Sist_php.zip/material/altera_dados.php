<html>
<body>
<?php include('../cabecalho.php');  ?>
<p>
  <?php
//$campo1= $_POST ['txtcampo1'];
$campo2= $_POST ['txtcampo2'];
$campo3= $_POST ['txtcampo3'];
$campo4= $_POST ['txtcampo4'];
$campo5= $_POST ['txtcampo5'];
$campo6= $_POST ['txtcampo6'];
$campo7= $_POST ['txtcampo7'];
$campo8= $_POST ['txtcampo8'];
$campo9= $_POST ['txtcampo9'];
$campo10= $_POST ['txtcampo10'];
$campo11= $_POST ['txtcampo11'];
$campo12= $_POST ['txtcampo12'];
$campo13= $_POST ['txtcampo13'];
$campo14= $_POST ['txtcampo14'];
$campo15= $_POST ['txtcampo15'];
$campo16= $_POST ['txtcampo16'];
$campo17= $_POST ['txtcampo17'];
$campo18= $_POST ['txtcampo18'];


//$txtemail= $_POST ['txtemail'];
$codigo= $_POST ['codigo'];

$bancox='central1';
$tabelax='test_prefixmaterial';
$conexao = mysql_connect ("mysql18.redehost.com.br","usuariorcentral","usuariocentral");
if (!$conexao) {
	die('Conexao nao Efeutada Falha: ' . mysql_error());  }
$banco_ok = mysql_select_db($bancox,$conexao);  // mysql 5.0 
if (!$banco_ok) {
	 die ('Erro na abertura de banco de dados: ' . mysql_error());   }

$altera="UPDATE $tabelax SET DESCRICAO='$campo3',DESCRICAO2='$campo5',UNIDADE='$campo7',VUNIT='$campo9',VUNIT2='$campo14',VUNIT3='$campo15',VUNIT4='$campo16',VUNIT5='$campo17',VUNIT6='$campo18',DATA='$campo2',DATA_COMP='$campo11',ESTMIN='$campo13',CODLT='$campo4',IPI='$campo13',PESOBR='$campo8',VLMINIMO='$campo12',EAN='$campo6' WHERE id='$codigo'";
	
	mysql_query($altera,$conexao) or die ("ocorreu algum erro!!!");
echo "<center> Dados gravados com sucesso...</center>";
?>

</p>
<p><center><a href="../cadastro.php">Tela de Cadastro Geral</a> | <a href="../cadastro.php?pagina=link3" class="link3">Exibe consulta</a></center></p>
<?php include('../rodape.php'); ?>
</body>
</html>