<?php 
require('classes/class.conexao.php');
class crud{
	public $rs;
	public $conn;
	///pego os campos postados
	public $codigo;
	public $categoria;
	public $abreviado;
	/// seta as variaveis dos erros
	public $errocodigo;
	public $errocategoria;
	public $erroabreviado;
	
	public function __construct(){
			$this->conn = new conexao();
	}
	public function selecionar(){
			$sql = "select * from categoria";
			$this->rs = mysql_query($this->conn->banco,$sql);
			//$this->rs = mysql_db_query($this->conn->banco,$sql);
	}	
	public function inserir($codigo,$categoria,$abreviado){
		$this->codigo=$codigo;
		$this->categoria=$categoria;
		$this->abreviado=$abreviado;
		echo "mostrando variavel ".$codigo.$categoria;
			if($this->codigo=='' or $this->categoria=='' or $this->abreviado==''){
				if($this->codigo=='')	{$this->errocodigo="Preecha o codigo!";}
				if($this->categoria=='')	{$this->errocategoria="Preecha a categoria!";}
				if($this->abreviado=='')	{$this->erroabreviado="Preecha nome abreviado!";}
				
			}else{
			 $sql = "insert into categoria(codigo,categoria,abreviado) values('$this->codigo','$this->categoria','$this->abreviado')";
			mysql_db_query($this->conn->banco,$sql);	
			//mysql_query($this->conn->banco,$sql);	
			$this->selecionar();
			echo "  chegou aqui linha 38 == ";
			}
		
		
	}	
		public function excluir(){
			$sql = "delete from categoria where id=".$_GET['id'];
			mysql_db_query($this->conn->banco,$sql);
	}	
	public function at(){
			$sql = "select * from categoria where id=".$_GET['id'];
			$this->rs =mysql_db_query($this->conn->banco,$sql);
	}	
	public function atualizar(){
			$nome=$_POST['txtcodigo'];
			$email=$_POST['txtcategoria'];
			$msg=$_POST['txtabreviado'];
			$id=$_POST['id'];
				
			$sql = "UPDATE categoria set codigo='$codigo',categoria='$categoria',abreviado='$abreviado'   where id=".$id;
			mysql_db_query($this->conn->banco,$sql);
	}	
}



?>