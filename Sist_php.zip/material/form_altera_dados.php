
<!-- abaixo codigo inserido  -->
<?php if (!isset($_SESSION)) { session_start();}?>
<?PHP
require($_SESSION['con2']);
$quem=$_GET['quem'];
$tabelax='material';
$consulta = "select * from $tabelax where id='$quem' ";
$resultado =mysql_query ($consulta,$conexao);
$linha = mysql_fetch_row ($resultado);

?>

<center>Altera��o de Dados</center>
<center><a href="../cadastro.php">Tela de Cadastro Geral</a> | <a href="../cadastro.php?pagina=link3" class="link3">Exibe consulta</a></center>
<form name="form" method="post" action="altera_dados.php">
    <table width="683" border="0" align="center" bgcolor="#FFFFCC">
    <tr>
      <td width="88">Codigo:</td>
      <td width="275"><input name="txtcampo1" type="text" value="<?php echo $linha[1];?>" size="12" maxlength="12" ReadOnly="True" /></td>
      <td width="10">&nbsp;</td>
      <td width="133">Dt. Cadastro:</td>
      <td width="143"><input type="text" name="txtcampo2" value="<?php echo $linha[2];?>" size="16" /></td>
    </tr>
    <tr>
      <td>Descri��o:</td>
      <td><input name="txtcampo3" type="text" value="<?php echo $linha[3];?>" size="40" maxlength="40" /></td>
      <td>&nbsp;</td>
      <td>Codigo Letra:</td>
      <td><input type="text" name="txtcampo4" value="<?php echo $linha[4];?>" size="5" /></td>
    </tr>
    <tr>
      <td>Descri��o2:</td>
      <td><input type="text" name="txtcampo5" value="<?php echo $linha[5];?>" size="40" /></td>
      <td>&nbsp;</td>
      <td>EAN:</td>
      <td><input type="text" name="txtcampo6" value="<?php echo $linha[6];?>" size="20" /></td>
    </tr>
    <tr>
      <td>Unidade:</td>
      <td><input type="text" name="txtcampo7" value="<?php echo $linha[7];?>" size="40" /></td>
      <td>&nbsp;</td>
      <td>Peso Br.:</td>
      <td><input type="text" name="txtcampo8" value="<?php echo $linha[8];?>" size="10" /></td>
    </tr>
    <tr>
      <td>Vl. Unit.</td>
      <td><input type="text" name="txtcampo9" value="<?php echo $linha[9];?>" size="20" /></td>
      <td>&nbsp;</td>
      <td>Valor Min.:</td>
      <td><input type="text" name="txtcampo10" value="<?php echo $linha[10];?>" size="14" /></td>
    </tr>
    <tr>
      <td>Dias Compra:</td>
      <td><input type="text" name="txtcampo11" value="<?php echo $linha[11];?>" size="5" /></td>
      <td>&nbsp;</td>
      <td>Estoque Min.:</td>
      <td><input type="text" name="txtcampo12" value="<?php echo $linha[12];?>" size="8" /></td>
    </tr>
    <tr>
      <td>IPI:</td>
      <td><input type="text" name="txtcampo13" value="<?php echo $linha[13];?>" size="6" /></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
  </table>
<hr />

  <table align="center" bgcolor="#FFFFCC">
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Vl Unit2:</td>
      <td><input type="text" name="txtcampo14" value="<?php echo $linha[14];?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Vl Unit3:</td>
      <td><input type="text" name="txtcampo15" value="<?php echo $linha[15];?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Vl. Unit4:</td>
      <td><input type="text" name="txtcampo16" value="<?php echo $linha[16];?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Vl. Unit5:</td>
      <td><input type="text" name="txtcampo17" value="<?php echo $linha[17];?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Vl. Unit6:</td>
      <td><input type="text" name="txtcampo18" value="<?php echo $linha[18];?>" size="32" /></td>
    </tr>
    
    <tr valign="baseline">
      <td colspan="2" align="right" nowrap="nowrap"><div align="center"></div></td>
    </tr>
    <tr>
      <td colspan="2"><div align="center">
        <input type ="submit" name="submit" value="Salvar" />
        <input name="reset" type="reset" id="reset" value="limpar" />
      </div></td>
    </tr>
  </table>
  <p><BR>
    <BR>
    <input type="hidden" name="codigo" value="<?php echo $linha[0];?>">
<BR>
  </p>
<?php include('../rodape.php'); ?>
</form>
