<?php header('Content-Type: text/html; charset=ISO-8859-1'); ?>
<?php 
include('includes/classes/pag_manu001.php');
$obj = new artistas(); 
$ordem=2;
$obj->selecionar($ordem);
$obj->paginacao('60');
?>

<?php
/*
echo "<table border ='1' align='center'>";
echo "<tr><td>";
echo "<a href='ins_001.php'>Inserir</a> | ";
echo "<a href='imp_001.php'>Imprimir</a> | ";
echo "<a href='his_001.php'>Historico</a> | ";
echo "<a href='obs_001.php'>Observação</a>";
echo "<td><a href='cadastro.php'>Finaliza essa rotina</a>";
//Pesquisa avancada
echo "<tr><td>";
echo "<center>Pesquisa Avancada ";
echo " <td> Ordenar:";
echo " Codigo | Nome";
echo "<BR>Nome: ..............................................";
echo " Cod. inicial: ........ Final ........ UF: ....<BR></center>";
echo "</table>";
*/

echo "<br><center>";
$obj->pagfirst();
$obj->pagprev();
$obj->paginar();
$obj->pagnext();
$obj->paglast();
echo "</center><BR>";

//echo "<font size='5'>";
echo "aula web";
echo "<center><table border=0 >";

		echo "<tr bgColor='#CCCCCC'><td>"."Codigo"."<td align='center'>"."Descricao do Produtoxxxxxxxxxxxxx"."<td>"."Unid."."<td>"." VL. Unitario  "."<td>"."Alterar"."<td>"."Excluir"."</tr>";	
		$tamfont=1;
		$volta=1;
		$cortab='#ffffff';
while($linha= mysql_fetch_object($obj->rs)){ 
		echo "<tr bgcolor='$cortab'><td><font size='$tamfont'>".$linha->CODMAT."</font><td><font size='$tamfont'>".$linha->DESCRICAO." ".$linha->DESCRICA2."</font><td align='center'><font size='$tamfont'>".$linha->UNIDADE."</font><td align='right'>"."<font size='$tamfont'>R$ ".number_format($linha->VUNIT,2,',','.')."</font><td align='center'>"."<A HREF='./material/form_altera_dados.php?quem=$linha->id'><img src='imagem/editar.jpg' height='28' width='32'></a>"."<td align='center'>"."<A HREF='./material/excluir.php?quem=$linha->id'><img src='imagem/lixeira.png' height='22' width='22'></A>"."</tr>";	

		if ($volta==1) {
		    $cortab='#ffffcc';
			$volta=0;}
		else {
		   $cortab='#ffffff';
		    $volta=$volta+1;		
		}

}
echo "</table></center>";
echo "</font>";
?>






