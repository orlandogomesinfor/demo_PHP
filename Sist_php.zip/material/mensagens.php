<?php require('includes/crud.php'); 
header('Content-Type: text/html; charset=utf-8');
$obj = new crud();
$obj->selecionar();

$enviado= $_POST['enviado'];
$inome= $_POST['txtcodigo'];
$iemail= $_POST['txtcategoria'];
$imsg= $_POST['txtabreviado'];

if($enviado=='1'){
	$obj->inserir($inome,$iemail,$imsg);
}


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<table width="844" height="67" border="0" cellpadding="10">
  <?php while($linha = mysql_fetch_object($obj->rs)){ ?>
  <tr>
    <td width="834"><?php echo $linha->nome; ?></td>
  </tr>
  <tr bgcolor="#EFEFEF">
    <td><?php echo $linha->msg; ?></td>
  </tr>
   <?php }?>
</table>
<form id="form1" name="form1" method="post" action="mensagens.php">
  <table width="843" border="0">
    <tr>
      <td colspan="3"><div align="center">
        <h1>Deixe um comentário:</h1>
      </div></td>
    </tr>
    <tr>
      <td width="73">Codigo:</td>
      <td width="274"><label for="txtcodigo2"></label>
        <input type="text" name="txtcodigo" id="txtcodigo2" /></td>
      <td width="474"> <?php if($obj->errocodigo){ echo $obj->errocodigo;}  ?> </td>
    </tr>
    <tr>
      <td height="24">Categoria:</td>
      <td><label for="txtcategoria"></label>
        <input type="text" name="txtcategoria" id="txtcategoria" /></td>
      <td><?php if($obj->errocategoria){ echo $obj->errocategoria;}  ?></td>
    </tr>
    <tr>
      <td>Abreviado:</td>
      <td><label for="txtabreviado"></label>
        <input name="txtabreviado" cols="40" id="txtabreviado" /></td>
      <td><?php if($obj->erroabreviado){ echo $obj->erroabreviado;}  ?></td>
    </tr>
    <tr>
      <td><input name="enviado" type="hidden" id="enviado" value="1" /></td>
      <td><input type="submit" name="button" id="button" value="Enviar" /></td>
      <td>&nbsp;</td>
    </tr>
  </table>
</form>
<p>&nbsp;</p>
</body>
</html>