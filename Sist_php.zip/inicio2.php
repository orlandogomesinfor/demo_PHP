<html>
<head>
<title>T�tulo</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
#apDiv1 {
	position:absolute;
	left:9px;
	top:15px;
	width:967px;
	height:55px;
	z-index:1;
}
#apDiv2 {
	position:absolute;
	left:14px;
	top:123px;
	width:86px;
	height:350px;
	z-index:2;
}
#apDiv3 {
	position:absolute;
	left:26px;
	top:125px;
	width:850px;
	height:340px;
	z-index:3;
}
#apDiv4 {
	position:absolute;
	left:891px;
	top:125px;
	width:82px;
	height:351px;
	z-index:4;
}
-->
</style>
</head>
<body bgcolor="#FFFFFF">
<div id="apDiv1">
  <?php include("cima.php"); ?>
</div>
<div id="apDiv3">
  <?php include("centro.php");   ?>
</div>
<div id="apDiv3">
<!-- < ? php include("centrobaixo.php");   ? -->
</div>
</body><html>