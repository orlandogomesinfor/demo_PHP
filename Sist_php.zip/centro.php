<table width="500" border="0" align="center" cellpadding="0" cellspacing="0">
<tr>
<td><?php echo ("<img src='ANIMAL_006.jpg' width='25%'");  ?></td>
<tr><td><?php echo (" AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA <BR> aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"); ?></td>
</tr>
</table>
