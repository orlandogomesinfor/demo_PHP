<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php include('../cabecalho.php'); ?>
<h2 align="center">Cadastro Realizado com Sucesso</h2>
<p align="center"><a href="../cadastro.php">Voltar a Tela de Principal de Cadastro</a> | <a href="inserir.php">Cadastrar novo Representante</a></p>

<p>&nbsp;</p>
<p>&nbsp;</p>
<?php include('../rodape.php');?>
</body>
</html>
