<?php 
if (!isset($_SESSION)) { session_start();}
error_reporting(0); 
require($_SESSION['con2']);
class artistas{
	public $rs;
	public $rstotal;
	public $sql;
	public $limit;
	public $rsporpg;
	public $numpags;

	public function __construct(){
			$this->conn = new conexao();
	}
	
	public function selecionar($ordemx){
	   $ordemxy = $ordemx;
	   echo "<center> Ordenar por: ";
       echo " <a href='?pagina=link2&pg=1&ordem=2'> Nome </a>&nbsp;&nbsp  ";	
	   echo " <a href='?pagina=link2&pg=1&ordem=1'> Codigo </a> &nbsp;&nbsp ";	
   	   echo " <a href='?pagina=link2&pg=1&ordem=3'> Bairro </a> &nbsp;&nbsp";
	   echo "&nbsp;&nbsp <a href='repre/inserir.php'>Novo Registro</a>&nbsp;&nbsp;&nbsp |";
	   echo "&nbsp;&nbsp<a href='cadastro.php'>Finaliza sess�o abaixo</a>  ";
	   $ordemxy = $_GET['ordem'];
	   if (isset($ordemxy)) {
		  if ($ordemxy == 1) {
			 $ordemx='CODREP';  } // $ordem =codigo
		  elseif ($ordemxy == 2) {   
			   $ordemx='RAZREP'; }
		  elseif ($ordemxy == 3) {   
			   $ordemx='BAIREP'; }
			}   
		else {
			   // Nao existe vai no else e criar categria
			   $ordemx='RAZREP'; 
			   }

	        $this->sql = "select * from rep order by $ordemx asc";
			$this->rs = mysql_db_query($this->conn->banco,$this->sql);
			$this->rstotal = mysql_num_rows($this->rs);
		}	
		
		public function paginacao($rsporpg){
			$this->rsporpg=$rsporpg;// seta total de registros por pagina
			$this->numpags = ceil($this->rstotal/$this->rsporpg);
			$inicio = ($_GET['pg']-1)*$this->rsporpg;
			//$inicio = '?pagina=link7&'.($_GET['pg']-1)*$this->rsporpg;
			if($_GET['pg']){
				$this->limit = $this->sql." limit $inicio, $this->rsporpg";
			}else{
				$this->limit = $this->sql." limit 1, $this->rsporpg";
			}
			$this->rs = mysql_db_query($this->conn->banco,$this->limit );	
		}	
		public function paginar(){
		    $i=1;
			while ($i <= $this->numpags){
			//echo " <a href='?pg=$i'> $i </a> ";

			if (isset($_GET['ordem'])) { 
	            $nn = $_GET['ordem'];
			 }
			 else { 
			   $nn=1;}

			echo " <a href='?pagina=link2&pg=$i&ordem=$nn'> $i </a> ";
			$i++;	
				
				}	
		}
		public function pagprev(){
			if($_GET['pg']){
				if($_GET['pg']!=1){
				$anterior = $_GET['pg']-1;
				//echo " <a href='?pg=$anterior'> < </a> ";

				if (isset($_GET['ordem'])) { 
	               $nn = $_GET['ordem'];
			     }
			    else { 
			       $nn=1;}

				echo " <a href='?pagina=link2&pg=$anterior&ordem=$nn'> < </a> ";
				}		
			}				
		}
		public function pagnext(){
			if($_GET['pg']){
				if($_GET['pg']!=$this->numpags){
				$proximo = $_GET['pg']+1;
				//echo " <a href='?pg=$proximo'> > </a> ";

				if (isset($_GET['ordem'])) { 
	               $nn = $_GET['ordem'];
			     }
			    else { 
			       $nn=1;}

				
				echo " <a href='?pagina=link2&pg=$proximo&ordem=$nn'> > </a> ";			
				}
			}		
		}
		
		public function pagfirst(){
				//echo " <a href='?pg=1'> << </a> ";

				if (isset($_GET['ordem'])) { 
	               $nn = $_GET['ordem'];
			     }
			    else { 
			       $nn=1;}
	
				echo " <a href='?pagina=link2&pg=1&ordem=$nn'> << </a> ";	
		}
		public function paglast(){
				//echo " <a href='?pg=$this->numpags'> >></a> ";
				if (isset($_GET['ordem'])) { 
	               $nn = $_GET['ordem'];
			     }
			    else { 
			       $nn=1;}

     			echo " <a href='?pagina=link2&pg=$this->numpags&ordem=$nn'> >> </a> ";	
		}
}
?>
