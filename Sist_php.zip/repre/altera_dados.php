<html>
<body>
<?php include('../cabecalho.php');  ?>
<p>
  <?php
//$campo1= $_POST ['txtcampo1'];
$campo2= $_POST ['txtcampo2'];
$campo3= $_POST ['txtcampo3'];
//$txtemail= $_POST ['txtemail'];
$codigo= $_POST ['codigo'];

$bancox='central1';
$tabelax='test_prefixrep';
$conexao = mysql_connect ("mysql18.redehost.com.br","usuariorcentral","usuariocentral");
if (!$conexao) {
	die('Conexao nao Efeutada Falha: ' . mysql_error());  }
$banco_ok = mysql_select_db($bancox,$conexao);  // mysql 5.0 
if (!$banco_ok) {
	 die ('Erro na abertura de banco de dados: ' . mysql_error());   }

$altera="UPDATE test_prefixrep SET categoria='$campo2',abreviado='$campo3' WHERE id='$codigo'";
	
	mysql_query($altera,$conexao) or die ("ocorreu algum erro!!!");
echo "<center> Dados gravados com sucesso...</center>";
?>

</p>
<p><center><a href="../cadastro.php">Tela de Cadastro Geral</a> | <a href="../cadastro.php?pagina=link4" class="link4">Exibe consulta</a></center></p>
<?php include('../rodape.php'); ?>
</body>
</html>