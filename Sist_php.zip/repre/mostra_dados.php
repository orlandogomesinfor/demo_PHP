<?php header('Content-Type: text/html; charset=ISO-8859-1'); ?>
<?php 
include('includes/classes/pag_manu001.php');
$obj = new artistas(); 
$ordem=2;
$obj->selecionar($ordem);
//$obj->selecionar();
$obj->paginacao('12');
?>

<!-- center><a href='cadastro.php'>Finaliza sess�o abaixo</a></center -->
<?php

//echo "<table align='center' border=0><tr><td><a href='representante/inserir.php'><img src='./imagem/btn_inserir.png'></a>  ";
//echo "<td><a href='cadastro.php'><img src='./imagem/btn_finalizar2.png'></a> </tr></table>" ;

/*
echo "<table border ='1' align='center'>";
echo "<tr>";
echo "<tr><td>";
echo "<center>Pesquisa Avancada ";

echo "<BR>Nome: ..............................................";
echo " Cod. inicial: ........ Final ........ UF: ....<BR></center>";
echo "</table>";
*/
echo "<center>";
$obj->pagfirst();
$obj->pagprev();
$obj->paginar();
$obj->pagnext();
$obj->paglast();
echo "</center>";
//echo "<font size='22'>";
echo "<center><table border=0 >";
		echo "<tr bgColor='#CCCCCC'><td>"."Codigo"."<td>"."     Nome     "."<td>"."Bairro"."<td>"."Telefone"."<td>"."Celular"."<TD>"."Alterar"."<td>"."Excluir"."</tr>";	
		$tamfont=3;
		$volta=1;
		$cortab='#ffffff';
while($linha= mysql_fetch_object($obj->rs)){ 
		echo "<tr bgcolor='$cortab'><td><font size='$tamfont'>".$linha->CODREP."</font><td><font size='$tamfont'>".$linha->RAZREP."</font> <td><font size='$tamfont'>".$linha->BAIREP."</font>"."</font> <td><font size='$tamfont'>".$linha->FONEREP."</font>"."</font> <td><font size='$tamfont'>".$linha->CELREP."</font>"."<td align='center'><A HREF='./grupo/form_altera_dados.php?quem=$linha->id'><img src='imagem/editar.jpg' height='28' width='32'></a>"."<td align='center'>"."<A HREF='cfop/excluir.php?quem=$linha->id'><img src='imagem/lixeira.png' height='22' width='22'></A>"."</tr>";	
		
		if ($volta==1) {
		    $cortab='#ffffcc';
			$volta=0;}
		else {
		   $cortab='#ffffff';
		    $volta=$volta+1;		
		}
	
}
echo "</table></center>";
echo "</font>";
 ?>

