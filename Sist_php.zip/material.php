<?php require_once('Connections/conexao.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$maxRows_rsmaterial = 10;
$pageNum_rsmaterial = 0;
if (isset($_GET['pageNum_rsmaterial'])) {
  $pageNum_rsmaterial = $_GET['pageNum_rsmaterial'];
}
$startRow_rsmaterial = $pageNum_rsmaterial * $maxRows_rsmaterial;


// rotina pesqusar
//$categ = $_POST['cat'];
//echo "veja : ".$categ."<BR>";
//echo "<BR> conteudo de novo do categ". $categ." fim bo categ<BR>";
//
mysql_select_db($database_conexao, $conexao);
$query_rsmaterial = "SELECT * FROM test_prefixmaterial ORDER BY test_prefixmaterial.CODMAT";
//$query_rsmaterial = "SELECT * FROM test_prefixmaterial where substr(test_prefixmaterial.CODMAT,1,3) = $categ ORDER BY test_prefixmaterial.CODMAT";
$query_limit_rsmaterial = sprintf("%s LIMIT %d, %d", $query_rsmaterial, $startRow_rsmaterial, $maxRows_rsmaterial);
$rsmaterial = mysql_query($query_limit_rsmaterial, $conexao) or die(mysql_error());
$row_rsmaterial = mysql_fetch_assoc($rsmaterial);

if (isset($_GET['totalRows_rsmaterial'])) {
  $totalRows_rsmaterial = $_GET['totalRows_rsmaterial'];
} else {
  $all_rsmaterial = mysql_query($query_rsmaterial);
  $totalRows_rsmaterial = mysql_num_rows($all_rsmaterial);
}
$totalPages_rsmaterial = ceil($totalRows_rsmaterial/$maxRows_rsmaterial)-1;

mysql_select_db($database_conexao, $conexao);
$query_cat = "SELECT categoria.codigo, categoria.categoria FROM categoria";
$cat = mysql_query($query_cat, $conexao) or die(mysql_error());
$row_cat = mysql_fetch_assoc($cat);
$totalRows_cat = mysql_num_rows($cat);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>


<p>&nbsp;</p>
<form id="form1" name="form1" method="post" action="material.php">
  <label>
  <select name="cat" id="cat">
    <?php
do {  
?>
    <option value="<?php echo $row_cat['codigo']?>"<?php if (!(strcmp($row_cat['codigo'], $row_cat['categoria']))) {echo "selected=\"selected\"";} ?>><?php echo $row_cat['categoria']?></option>
    <?php
} while ($row_cat = mysql_fetch_assoc($cat));
  $rows = mysql_num_rows($cat);
  if($rows > 0) {
      mysql_data_seek($cat, 0);
	  $row_cat = mysql_fetch_assoc($cat);
  }
?>
  </select>
  </label>
  <input type="submit" name="button" id="button" value="Pesquisar" />
</form>
<label></label>
<p>&nbsp;</p>
<table width="100%" border="1">
  <tr>
    <td>Codigo</td>
    <td>Descrição</td>
    <td>Vl. Unit.</td>
    <td>IPI</td>
    <td>EAN</td>
    <td>&nbsp;</td>
  </tr>
  <?php do { ?>
    <tr>
      <td><?php echo $row_rsmaterial['CODMAT']; ?></td>
      <td><?php echo $row_rsmaterial['DESCRICAO']; ?><?php echo $row_rsmaterial['DESCRICA2']; ?></td>
      <td><?php echo $row_rsmaterial['VUNIT']; ?></td>
      <td><?php echo $row_rsmaterial['IPI']; ?></td>
      <td><?php echo $row_rsmaterial['EAN']; ?></td>
      <td>&nbsp;</td>
    </tr>
    <?php } while ($row_rsmaterial = mysql_fetch_assoc($rsmaterial)); ?>
</table>
<p>&nbsp;</p>
</body>
</html>
<?php
mysql_free_result($rsmaterial);

mysql_free_result($cat);
?>
