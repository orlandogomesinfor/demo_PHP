<?php 
include('include/pag_requis.php');
$obj = new artistas(); 
$obj->selecionar();
$obj->paginacao('25');
echo "<h2 align=center>Lista de Requisi��o</h2>";
echo "<center>";
echo "<table border=1 >";
echo "<tr><td>"."Empresa"."<td>"."Requisi��o"."<td>"." Data Req. "."<td>"."  Cliente  "."<td>"."Fatura"."<td>"."Num. NF"."<td>"." Data NF "."<td>"." UF "."<td>"." Num. Exetrno"."</tr>";			
while($linha= mysql_fetch_object($obj->rs)){ 
		//echo $linha->DESCRICAO."</br>";	
		//echo "<tr><td>".$linha->NUMCON."<td>".$linha->NUMREQ."<td>".$linha->DATREQ."<td>".$linha->CODCLI."<td>".$linha->EMPRESA."<td>".$linha->FATURADA."<td>".$linha->NUMNF."td".$linha->DATANF."<td>".$linha->CFOP."<td>".$linha->SIGLA."<td>".$linha->IPI."<td>".$linha->NUMEXT."<td>".$linha->IPI."</tr>";	
		$anox=substr($linha->DATREQ,0,4);
		$mesx=substr($linha->DATREQ,5,2);
		$diax=substr($linha->DATREQ,8,2);
		$datareqx=$diax."/".$mesx."/".$anox;
		$anonfx=substr($linha->DATANF,0,4);
		$mesnfx=substr($linha->DATANF,5,2);
		$dianfx=substr($linha->DATANF,8,2);
		$datanfx=$dianfx."/".$mesnfx."/".$anonfx;
	    
	    //echo "<tr><td>".$linha->EMPRESA."<td>".$linha->NUMREQ."<td>".$datareqx."<td>".$linha->CODCLI."<td>".$linha->FATURADA."<td>".$linha->NUMNF."<td>".$datanfx."<td>".$linha->CFOP."<td>".$linha->SIGLA."<td>".$linha->IPI."<td>".$linha->NUMEXT."<td>".$linha->IPI."</tr>";	
        echo "<tr><td>".$linha->EMPRESA."<td>".$linha->NUMREQ."<td>".$datareqx."<td>".$linha->CODCLI."<td>".$linha->FATURADA."<td>".$linha->NUMNF."<td>".$datanfx."<td>".$linha->SIGLA."<td>".$linha->NUMEXT."</tr>";			
}
echo "</table></center>";

echo "<br><center>";
$obj->pagfirst();
$obj->pagprev();
$obj->paginar();
$obj->pagnext();
$obj->paglast();
echo "</center>";


?>'