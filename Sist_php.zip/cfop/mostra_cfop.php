<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php 
include('includes/classes/pag_manu001.php');
$obj = new artistas(); 
$ordem=2;
$obj->selecionar($ordem);
//$obj->selecionar();
$obj->paginacao('15');
?>

<!-- center><a href='cadastro.php'>Finaliza sessão abaixo</a></center -->
<?php
//echo "<table align='center' border=0><tr><td><a href='cfop/inserir.php'><img src='./imagem/btn_inserir.png'></a>  ";
//echo "<td><a href='cadastro.php'><img src='./imagem/btn_finalizar2.png'></a> </tr></table>" ;

echo "<center>";
$obj->pagfirst();
$obj->pagprev();
$obj->paginar();
$obj->pagnext();
$obj->paglast();
echo "</center>";
//echo "<font size='22'>";
echo "<center><table border=0 >";
		echo "<tr bgColor='#CCCCCC'><td>"." ID "."<td>"."Codigo"."<td>"."     Operacao     "."<td>"."Tipo"."<td>"."Alterar"."<td>"."Excluir"."</tr>";	
		$tamfont=3;
		$volta=1;
		$cortab='#ffffff';
while($linha= mysql_fetch_object($obj->rs)){ 
		echo "<tr bgcolor='$cortab'><td><font size='$tamfont'>".$linha->id."</font><td><font size='$tamfont'>".$linha->CODOPE."</font><td><font size='$tamfont'>".$linha->OPERACAO."</font> <td align='center'><font size='$tamfont'>".$linha->TIPO."</font>"."<td align='center'><A HREF='./cfop/form_altera_dados.php?quem=$linha->id'><img src='imagem/editar.jpg' height='28' width='32'></a>"."<td align='center'>"."<A HREF='cfop/mostrar_excluir_dados.php?quem=$linha->id'><img src='imagem/lixeira.png' height='22' width='22'></A>"."</tr>";	
		
		if ($volta==1) {
		    $cortab='#ffffcc';
			$volta=0;}
		else {
		   $cortab='#ffffff';
		    $volta=$volta+1;		
		}
}
echo "</table></center>";
echo "</font>";
 ?>

