<?PHP error_reporting(0); ?>
<?PHP   session_start(); ?>
<?php include('../cabecalho.php');  ?>
<p>
<?php
$campo1= $_POST ['txtcampo1'];
$campo2= $_POST ['txtcampo2'];
$campo3= $_POST ['txtcampo3'];
$campo4= $_POST ['txtcampo4'];
$codigo= $_POST ['codigo'];
// $quem=$_GET['quem'];
//------------------------------------------
//<?php if (!isset($_SESSION)) { session_start();}? >
if ($_SESSION['cntip']<>1) {
   $bancox='central1';
   $tabelax='test_prefixnfopera';
   $conexao = mysql_connect ("mysql18.redehost.com.br","usuariorcentral","usuariocentral");
   if (!$conexao) { die('Conexao nao Efeutada Falha: ' . mysql_error());  }
   $banco_ok = mysql_select_db($bancox,$conexao);  // mysql 5.0 
   if (!$banco_ok) { die ('Erro na abertura de banco de dados: ' . mysql_error());   }
      //$quem=$_GET['quem'];
      //$consulta = "select * from $tabelax where id='$quem' ";
      //$resultado =mysql_query ($consulta,$conexao);
      //$linha = mysql_fetch_row ($resultado);
}
else
{
   $servidor="localhost";
   $login="root";
   $senha="";
   $bancox="bdcentral";     //  "central1"; 
   $tabelax='test_prefixnfopera';
   $conexao = mysql_connect ($servidor,$login,$senha);
   if (!$conexao) { die('Conexao nao Efeutada Falha: ' . mysql_error());  }
   $banco_ok = mysql_select_db($bancox,$conexao);  // mysql 5.0 
   if (!$banco_ok) { die ('Erro na abertura de banco de dados: ' . mysql_error());   }
      //$quem=$_GET['quem'];
      //$consulta = "select * from $tabelax where id='$quem' ";
      //$resultado =mysql_query ($consulta,$conexao);
      //$linha = mysql_fetch_row ($resultado);
}


//-------------------------------------------

//$bancox='central1';
//$tabelax='test_prefixnfopera';
//$conexao = mysql_connect ("mysql18.redehost.com.br","usuariorcentral","usuariocentral");
//if (!$conexao) {
//	die('Conexao nao Efeutada Falha: ' . mysql_error());  }
//$banco_ok = mysql_select_db($bancox,$conexao);  // mysql 5.0 
//if (!$banco_ok) {
//	 die ('Erro na abertura de banco de dados: ' . mysql_error());   }

$altera="UPDATE $tabelax SET operacao='$campo2',tipo='$campo3',estoque='$campo4' WHERE id='$codigo'";
	
	mysql_query($altera,$conexao) or die ("ocorreu algum erro!!!");
echo "<center> Dados gravados com sucesso...</center>";
?>

</p>
<p><center><a href="../cadastro.php">Tela de Cadastro Geral</a> | <a href="../cadastro.php?pagina=link6" class="link6">Exibe consulta</a></center></p>
<?php include('../rodape.php'); ?>
