<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php if (!isset($_SESSION)) { session_start();}
error_reporting(0);
require($_SESSION['con2']);
class artistas{
	public $rs;
	public $rstotal;
	public $sql;
	public $limit;
	public $rsporpg;
	public $numpags;
	public function __construct(){
			$this->conn = new conexao();
	}
	public function selecionar($ordemx){
	   $ordemxy = $ordemx;
	   echo "<table align='center' border='0'><tr><td>";
	   echo "Ordenar por: ";
       echo " <a href='?pagina=link6&pg=1&ordem=2'> Descricao </a> | ";	
	   echo " <a href='?pagina=link6&pg=1&ordem=1'> CFOP </a> | ";	
   	   echo " <a href='?pagina=link6&pg=1&ordem=3'> ID </a> ";	
	    echo "<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='./cfop/inserir.php'>Novo Registro</a>  ";
   	   echo "<td> | <a href='cadastro.php'>Finaliza sessao abaixo</a></tr></table> ";
	   
	   $ordemxy = $_GET['ordem'];
	   if (isset($ordemxy)) {
		  if ($ordemxy == 1) {
			 $ordemx='CODOPE';  } // $ordem =codigo
		  elseif ($ordemxy == 2) {   
			   $ordemx='OPERACAO'; }
		  elseif ($ordemxy == 3) {   
			   $ordemx='id'; }
			}   
		else {
			   // Nao existe vai no else e criar categria
			   $ordemx='OPERACAO'; 
			   }
	        $this->sql = "select * from nfopera order by $ordemx asc";
			$this->rs = mysql_db_query($this->conn->banco,$this->sql);
			$this->rstotal = mysql_num_rows($this->rs);
		}	

		public function paginacao($rsporpg){
			$this->rsporpg=$rsporpg;// seta total de registros por pagina
			$this->numpags = ceil($this->rstotal/$this->rsporpg);
			$inicio = ($_GET['pg']-1)*$this->rsporpg;
			//$inicio = '?pagina=link7&'.($_GET['pg']-1)*$this->rsporpg;

			if($_GET['pg']){
				$this->limit = $this->sql." limit $inicio, $this->rsporpg";
			}else{
				$this->limit = $this->sql." limit 1, $this->rsporpg";
			}
			$this->rs = mysql_db_query($this->conn->banco,$this->limit );	
		}	

		public function paginar(){
		    $i=1;
			while ($i <= $this->numpags){
			//echo " <a href='?pg=$i'> $i </a> ";
			if (isset($_GET['ordem'])) { 
	            $nn = $_GET['ordem'];
			 }
			 else { 
			   $nn=1;}
			echo " <a href='?pagina=link6&pg=$i&ordem=$nn'> $i </a> ";
			$i++;	
				}	
		}

		public function pagprev(){
			if($_GET['pg']){
				if($_GET['pg']!=1){
				$anterior = $_GET['pg']-1;
				//echo " <a href='?pg=$anterior'> < </a> ";
				if (isset($_GET['ordem'])) { 
	               $nn = $_GET['ordem'];
			     }
			    else { 
			       $nn=1;}
				echo " <a href='?pagina=link6&pg=$anterior&ordem=$nn'> < </a> ";
				}		
			}				
		}

		public function pagnext(){
			if($_GET['pg']){
				if($_GET['pg']!=$this->numpags){
				$proximo = $_GET['pg']+1;
				//echo " <a href='?pg=$proximo'> > </a> ";
				if (isset($_GET['ordem'])) { 
	               $nn = $_GET['ordem'];
			     }
			    else { 
			       $nn=1;}
				echo " <a href='?pagina=link6&pg=$proximo&ordem=$nn'> > </a> ";			
				}
			}		
		}

		public function pagfirst(){
				//echo " <a href='?pg=1'> << </a> ";
				if (isset($_GET['ordem'])) { 
	               $nn = $_GET['ordem'];
			     }
			    else { 
			       $nn=1;}
				echo " <a href='?pagina=link6&pg=1&ordem=$nn'> << </a> ";	
		}

		public function paglast(){
				//echo " <a href='?pg=$this->numpags'> >></a> ";
				if (isset($_GET['ordem'])) { 
	               $nn = $_GET['ordem'];
			     }
			    else { 
			       $nn=1;}
     			echo " <a href='?pagina=link6&pg=$this->numpags&ordem=$nn'> >> </a> ";	
		}
}
?>

