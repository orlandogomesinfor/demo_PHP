<?php require_once('Connections/conexao.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO categoria (codigo, categoria, abreviado) VALUES (%s, %s, %s)",
                       GetSQLValueString($_POST['codigo'], "text"),
                       GetSQLValueString($_POST['categoria'], "text"),
                       GetSQLValueString($_POST['abreviado'], "text"));

  mysql_select_db($database_conexao, $conexao);
  $Result1 = mysql_query($insertSQL, $conexao) or die(mysql_error());

  $insertGoTo = "sucesso_material.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form2")) {
  $insertSQL = sprintf("INSERT INTO material (id, idcateg, codigo, descricao, descricao2, unidade, vunit, vunit2, vunit3, vunit4, vunit5, vunit6, `data`, dataalt, dias_comp, estmin, codlt, ipi, pesobr, vlminimo, ean) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['id'], "int"),
                       GetSQLValueString($_POST['idcateg'], "int"),
                       GetSQLValueString($_POST['codigo'], "text"),
                       GetSQLValueString($_POST['descricao'], "text"),
                       GetSQLValueString($_POST['descricao2'], "text"),
                       GetSQLValueString($_POST['unidade'], "text"),
                       GetSQLValueString($_POST['vunit'], "int"),
                       GetSQLValueString($_POST['vunit2'], "int"),
                       GetSQLValueString($_POST['vunit3'], "int"),
                       GetSQLValueString($_POST['vunit4'], "int"),
                       GetSQLValueString($_POST['vunit5'], "int"),
                       GetSQLValueString($_POST['vunit6'], "int"),
                       GetSQLValueString($_POST['data'], "date"),
                       GetSQLValueString($_POST['dataalt'], "date"),
                       GetSQLValueString($_POST['dias_comp'], "int"),
                       GetSQLValueString($_POST['estmin'], "int"),
                       GetSQLValueString($_POST['codlt'], "text"),
                       GetSQLValueString($_POST['ipi'], "int"),
                       GetSQLValueString($_POST['pesobr'], "int"),
                       GetSQLValueString($_POST['vlminimo'], "int"),
                       GetSQLValueString($_POST['ean'], "text"));

  mysql_select_db($database_conexao, $conexao);
  $Result1 = mysql_query($insertSQL, $conexao) or die(mysql_error());
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form2")) {
  $insertSQL = sprintf("INSERT INTO material (id, idcateg, codigo, descricao, descricao2, unidade, vunit, vunit2, vunit3, vunit4, vunit5, vunit6, `data`, dataalt, dias_comp, estmin, codlt, ipi, pesobr, vlminimo, ean) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['id'], "int"),
                       GetSQLValueString($_POST['idcateg'], "int"),
                       GetSQLValueString($_POST['codigo'], "text"),
                       GetSQLValueString($_POST['descricao'], "text"),
                       GetSQLValueString($_POST['descricao2'], "text"),
                       GetSQLValueString($_POST['unidade'], "text"),
                       GetSQLValueString($_POST['vunit'], "int"),
                       GetSQLValueString($_POST['vunit2'], "int"),
                       GetSQLValueString($_POST['vunit3'], "int"),
                       GetSQLValueString($_POST['vunit4'], "int"),
                       GetSQLValueString($_POST['vunit5'], "int"),
                       GetSQLValueString($_POST['vunit6'], "int"),
                       GetSQLValueString($_POST['data'], "date"),
                       GetSQLValueString($_POST['dataalt'], "date"),
                       GetSQLValueString($_POST['dias_comp'], "int"),
                       GetSQLValueString($_POST['estmin'], "int"),
                       GetSQLValueString($_POST['codlt'], "text"),
                       GetSQLValueString($_POST['ipi'], "int"),
                       GetSQLValueString($_POST['pesobr'], "int"),
                       GetSQLValueString($_POST['vlminimo'], "int"),
                       GetSQLValueString($_POST['ean'], "text"));

  mysql_select_db($database_conexao, $conexao);
  $Result1 = mysql_query($insertSQL, $conexao) or die(mysql_error());
}

mysql_select_db($database_conexao, $conexao);
$query_Recordset_categoria = "SELECT * FROM categoria where categoria.id=2";
$Recordset_categoria = mysql_query($query_Recordset_categoria, $conexao) or die(mysql_error());
$row_Recordset_categoria = mysql_fetch_assoc($Recordset_categoria);
$totalRows_Recordset_categoria = mysql_num_rows($Recordset_categoria);

mysql_select_db($database_conexao, $conexao);
$query_Recordset1 = "SELECT * FROM categoria  WHERE categoria.id=2";
$Recordset1 = mysql_query($query_Recordset1, $conexao) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);

mysql_select_db($database_conexao, $conexao);
$query_Recordset2 = "SELECT * FROM material";
$Recordset2 = mysql_query($query_Recordset2, $conexao) or die(mysql_error());
$row_Recordset2 = mysql_fetch_assoc($Recordset2);
$totalRows_Recordset2 = mysql_num_rows($Recordset2);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<p>Inserir em duas Tabelas</p>
<p>&nbsp; </p>

<form action="<?php echo $editFormAction; ?>" method="post" name="form1" id="form1">
  <table align="center">
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Codigo:</td>
      <td><input type="text" name="codigo" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Categoria:</td>
      <td><input type="text" name="categoria" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Abreviado:</td>
      <td><input type="text" name="abreviado" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">&nbsp;</td>
      <td><input type="submit" value="Inserir" /></td>
    </tr>
  </table>
  <p>&nbsp;  </p>
  <p>
    <input type="hidden" name="MM_insert" value="form1" />
    </p>
</form>
<p>&nbsp;</p>

<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>

<form action="<?php echo $editFormAction; ?>" method="post" name="form2" id="form2">
  <table align="center">
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Id:</td>
      <td><input type="text" name="id" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Idcateg:</td>
      <td><input type="text" name="idcateg" value="<?php echo $row_Recordset1['id']; ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Codigo:</td>
      <td><input type="text" name="codigo" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Descricao:</td>
      <td><input type="text" name="descricao" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Descricao2:</td>
      <td><input type="text" name="descricao2" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Unidade:</td>
      <td><input type="text" name="unidade" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Vunit:</td>
      <td><input type="text" name="vunit" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Vunit2:</td>
      <td><input type="text" name="vunit2" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Vunit3:</td>
      <td><input type="text" name="vunit3" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Vunit4:</td>
      <td><input type="text" name="vunit4" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Vunit5:</td>
      <td><input type="text" name="vunit5" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Vunit6:</td>
      <td><input type="text" name="vunit6" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Data:</td>
      <td><input type="text" name="data" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Dataalt:</td>
      <td><input type="text" name="dataalt" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Dias_comp:</td>
      <td><input type="text" name="dias_comp" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Estmin:</td>
      <td><input type="text" name="estmin" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Codlt:</td>
      <td><input type="text" name="codlt" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Ipi:</td>
      <td><input type="text" name="ipi" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Pesobr:</td>
      <td><input type="text" name="pesobr" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Vlminimo:</td>
      <td><input type="text" name="vlminimo" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Ean:</td>
      <td><input type="text" name="ean" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">&nbsp;</td>
      <td><input type="submit" value="Insert record" /></td>
    </tr>
  </table>
  <input type="hidden" name="MM_insert" value="form2" />
</form>
<p>&nbsp;</p>
</body>
</html>
<?php
mysql_free_result($Recordset_categoria);

mysql_free_result($Recordset1);

mysql_free_result($Recordset2);
?>
