<?php
/*
Estou começando um projeto para emissão de nota fiscal em php e mysql
e gostaria da colaboração de todos para que fique excelente.
Os scripts sao os seguintes:

Arquivo gera.php
//Gera o arquivo xml que será enviado para a receita:

http://php-brasil.4461.n7.nabble.com/Projeto-de-Nota-Fiscal-Eletronica-em-php-td31414.html

Script desenvolvido por Celio Alexandre Galli
http://www.planetariobranco.com.br
[hidden email]
Entre em contato para alguma sugestão de melhoramento...
*/

/*Faz a conexão ao bando de dados -> crie um banco de dados qualquer
com as variaveis que serao usadas
*/
include "conecta.php";

/*Abre um arquivo chamado xml_gerado.xml (aconselhavel criar o arquivo
manualmente e mudar atributos para gravar e ler 777 recomendado...
*/
$vai_xml = fopen("xlm_gerado.xml","w+");

/*Começamos a gravar os dados no arquivo xlm....*/
fwrite($vai_xml,"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
fwrite($vai_xml,'<NFe xmlns="http://www.portalfiscal.inf.br/nfe">');
fwrite($vai_xml,'<infNFe
Id="NFe35080599999090910270550010000000015180051273" versao="1.10">');
fwrite($vai_xml,"<ide>\n");
fwrite($vai_xml,"<cUF>35</cUF>\n");
fwrite($vai_xml,"<cNF>518005127</cNF>\n");
fwrite($vai_xml,"<natOp>Venda a vista</natOp>\n");
fwrite($vai_xml,"<indPag>0</indPag>\n");
fwrite($vai_xml,"<mod>55</mod>\n");
fwrite($vai_xml,"<serie>1</serie>\n");
fwrite($vai_xml,"<nNF>1</nNF>\n");
fwrite($vai_xml,"<dEmi>2008-05-06</dEmi>\n");
fwrite($vai_xml,"<dSaiEnt>2008-05-06</dSaiEnt>\n");
fwrite($vai_xml,"<tpNF>0</tpNF>\n");
fwrite($vai_xml,"<cMunFG>3550308</cMunFG>\n");
fwrite($vai_xml,"<tpImp>1</tpImp>\n");
fwrite($vai_xml,"<tpEmis>1</tpEmis>\n");
fwrite($vai_xml,"<cDV>3</cDV>\n");
fwrite($vai_xml,"<tpAmb>2</tpAmb>\n");
fwrite($vai_xml,"<finNFe>1</finNFe>\n");
fwrite($vai_xml,"<procEmi>0</procEmi>\n");
fwrite($vai_xml,"<verProc>NF-eletronica.com</verProc>\n");
fwrite($vai_xml,"</ide>\n");
fwrite($vai_xml,"<emite>\n");
fwrite($vai_xml,"<CNPJ>99999090910270</CNPJ>\n");
fwrite($vai_xml,"<xNome>NF-e Associacao NF-e</xNome>\n");
fwrite($vai_xml,"<xFant>NF-e</xFant>\n");
fwrite($vai_xml,"<enderEmit>\n");
fwrite($vai_xml,"<xLgr>Rua Central</xLgr>\n");
fwrite($vai_xml,"<nro>100</nro>\n");
fwrite($vai_xml,"<xCpl>Fundos</xCpl>\n");
fwrite($vai_xml,"<xBairro>Distrito Industrial</xBairro>\n");
fwrite($vai_xml,"<cMun>3502200</cMun>\n");
fwrite($vai_xml,"<xMun>Angatuba</xMun>\n");
fwrite($vai_xml,"<UF>SP</UF>\n");
fwrite($vai_xml,"<CEP>17100171</CEP>\n");
fwrite($vai_xml,"<cPais>1058</cPais>\n");
fwrite($vai_xml,"<xPais>Brasil</xPais>\n");
fwrite($vai_xml,"<fone>1733021717</fone>\n");
fwrite($vai_xml,"</enderEmit>\n");
fwrite($vai_xml,"<IE>123456789012</IE>\n");
fwrite($vai_xml,"</emite>\n");
fwrite($vai_xml,"<dest>\n");
fwrite($vai_xml,"<CNPJ>00000000000191</CNPJ>\n");
fwrite($vai_xml,"<xNome>DISTRIBUIDORA DE AGUAS MINERAIS</xNome>\n");
fwrite($vai_xml,"<enderDest>\n");
fwrite($vai_xml,"<xLgr>AV DAS FONTES</xLgr>\n");
fwrite($vai_xml,"<nro>1777</nro>\n");
fwrite($vai_xml,"<xCpl>10 ANDAR</xCpl>\n");
fwrite($vai_xml,"<xBairro>PARQUE FONTES</xBairro>\n");
fwrite($vai_xml,"<cMun>5030801</cMun>\n");
fwrite($vai_xml,"<xMun>Sao Paulo</xMun>\n");
fwrite($vai_xml,"<UF>SP</UF>\n");
fwrite($vai_xml,"<CEP>13950000</CEP>\n");
fwrite($vai_xml,"<cPais>1058</cPais>\n");
fwrite($vai_xml,"<xPais>BRASIL</xPais>\n");
fwrite($vai_xml,"<fone>1932011234</fone>\n");
fwrite($vai_xml,"</enderDest>\n");
fwrite($vai_xml,"<IE></IE>\n");
fwrite($vai_xml,"</dest>\n");
fwrite($vai_xml,"<retirada>\n");
fwrite($vai_xml,"<CNPJ>99171171000194</CNPJ>\n");
fwrite($vai_xml,"<xLgr>AV PAULISTA</xLgr>\n");
fwrite($vai_xml,"<nro>12345</nro>\n");
fwrite($vai_xml,"<xCpl>TERREO</xCpl>\n");
fwrite($vai_xml,"<xBairro>CERQUEIRA CESAR</xBairro>\n");
fwrite($vai_xml,"<cMun>3550308</cMun>\n");
fwrite($vai_xml,"<xMun>SAO PAULO</xMun>\n");
fwrite($vai_xml,"<UF>SP</UF>\n");
fwrite($vai_xml,"</retirada>\n");
fwrite($vai_xml,"<entrega>\n");
fwrite($vai_xml,"<CNPJ>99299299000194</CNPJ>\n");
fwrite($vai_xml,"<xLgr>AV FARIA LIMA</xLgr>\n");
fwrite($vai_xml,"<nro>1500</nro>\n");
fwrite($vai_xml,"<xCpl>15 ANDAR</xCpl>\n");
fwrite($vai_xml,"<xBairro>PINHEIROS</xBairro>\n");
fwrite($vai_xml,"<cMun>3550308</cMun>\n");
fwrite($vai_xml,"<xMun>SAO PAULO</xMun>\n");
fwrite($vai_xml,"<UF>SP</UF>\n");
fwrite($vai_xml,"</entrega>\n");
fwrite($vai_xml,'<det nItem="1">\n');

fwrite($vai_xml,'</det>\n');

fwrite($vai_xml,"</infNFe>\n");
fwrite($vai_xml,"</NFe>\n"); 
?>