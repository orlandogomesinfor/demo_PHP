<!-- http://www.gsmfans.com.br/index.php?topic=136017.0 -->

<html>
<head>
<title>Sistema Central</title>
<link href="estilos2.css" rel="stylesheet" type="text/css">
</head><body>

<div id="container">
      <div id="cabecalho"> <table width="100%" border="1" cellspacing="0" cellpadding="0">
  <tr>
    <td width="24%"> SISTEMAS  </td>
    <td width="43%"><center>
      SISTEMA CENTRAL
    </center></td>
    <td width="33%">
    <center> Versao: 1.0 | Usuario: Padrao<br> 
    <a href="index.php?pagina=link1" class="link1"><span>inicio</span></a> | <a href="index.php?pagina=link2" class="link2"><span>troca usuario</span></a> 
    | <a href="index.php?pagina=link1" class="link1"><span>Sair</span></a> </center>
    </td>
  </tr>
 </table>


   </div>
     <div id="menu_esquerdo">
                <hr><center>         
               <a href="index.php?pagina=link1" class="link1"><span>Material</span></a> 
                | <a href="index.php?pagina=link2" class="link2"><span>Cliente</span></a> 
                | <a href="index.php?pagina=link3" class="link3"><span>Representante</span></a> 
                | <a href="index.php?pagina=link4" class="link4"><span>UF</span></a> 
                | <a href="index.php?pagina=link5" class="link5"><span>AAAA</span></a>
                | <a href="index.php?pagina=link1" class="link1"><span>BBBBB </span></a>
      </div>
      <div id="caixa">
      <?php
	 /* if (isset($_GET['pagina'])) {
          echo "Essa variavel existe.<BR>";} */
		  
      if($_GET['pagina'] == 'link1') {
	    include "pag/manu_001.php";         }
      elseif($_GET['pagina'] == 'link2')  {
        include "pag/link2.php";         }
      elseif($_GET['pagina'] == 'link3')  {
 	    include "pag/link3.php";         } 
      elseif($_GET['pagina'] == 'link4')   {
	    include "pag/link4.php"; } 
      elseif($_GET['pagina'] == 'link5')   {
	    include "pag/link5.php"; } 
      
	  /*elseif($_GET['pagina'] == 'link6')   { 
	    include "manu_001.php"; } //manu_001.php";   }  
      elseif($_GET['pagina'] == 'link7')   { 
	    include "paginacao_material1.php";  }
      elseif($_GET['pagina'] == 'link8')   { 
	    include "paginacao_requis.php";     }		
      elseif($_GET['pagina'] == 'link9')   { 
	    include "manu_001.php";  }		*/
						
      else  { 
	    include "pag/link1.php";         }
      ?>   
   </div>  
   <div id="rodape"> 
     <BR><BR><BR><hr>   
     <center>
     Sistema Central - Controle e Gestao Administrativo<BR>
      Direitos Reservados a Semog Solucoes WEB<BR> Contato: semog_tecnica@hotmail.com</center>
    </div>
</div>
</body>
</html>