<?php require('../includes/crud.php'); 
header('Content-Type: text/html; charset=utf-8');
$obj = new crud();
$obj->selecionar();


if($_GET['id']){
	$obj->at();
	
}


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<form id="form1" name="form1" method="post" action="emensagens.php">
  <table width="843" border="0">
    <tr>
      <td colspan="3"><div align="center">
        <h1>Deixe um comentário:</h1>
      </div></td>
    </tr>
    <tr>
      <td width="73">Nome:</td>
      <td width="274">
      <?php $retorno =  mysql_fetch_object($obj->rs); ?>
        <input name="txtnome" type="text"  value="<?php echo $retorno->nome; ?>" /></td>
      <td width="474">&nbsp;</td>
    </tr>
    <tr>
      <td height="24">Email:</td>
      <td><label for="txtemail"></label>
        <input name="txtemail" type="text" id="txtemail" value="<?php echo $retorno->email; ?>" /></td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>Mensagem:</td>
      <td><label for="txtmsg"></label>
        <textarea name="txtmsg" cols="40" id="txtmsg"><?php echo $retorno->msg; ?></textarea></td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td><input name="atualizar" type="hidden" id="atualizar" value="1" />
      <input name="id" type="hidden" id="id" value="<?php echo $retorno->id; ?>" /></td>
      <td><input type="submit" name="button" id="button" value="Atualizar" /></td>
      <td>&nbsp;</td>
    </tr>
  </table>
</form>
<p>&nbsp;</p>
</body>
</html>