<?php require('../includes/crud.php'); 
header('Content-Type: text/html; charset=utf-8');
$obj = new crud();
$obj->selecionar();


if($_GET['id']){
	$obj->excluir();
	$obj->selecionar();
}
if($_POST['atualizar']==1){
	$obj->atualizar();	
	$obj->selecionar();
}


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script type="text/javascript">
		function apagar(id){
			if(confirm('Deseja realmente apagar ?')){
				location.href="emensagens.php?id="+id
			}
		}
</script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<table width="844" height="67" border="0" cellpadding="10">
  <?php while($linha = mysql_fetch_object($obj->rs)){ ?>
  <tr>
    <td width="602"><?php echo $linha->nome; ?></td>
    <td width="196"><a href="amensagens.php?id=<?php echo $linha->id; ?>"> Editar </a> <a href="#"  onclick="apagar(<?php echo $linha->id; ?>)"> Excluir </a> </td>
  </tr>
  <tr bgcolor="#EFEFEF">
    <td colspan="2"><?php echo $linha->msg; ?></td>
  </tr>
   <?php }?>
</table>
<p>&nbsp;</p>
</body>
</html>