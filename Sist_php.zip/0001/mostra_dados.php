<?php header('Content-Type: text/html; charset=ISO-8859-1'); ?>
<?php //include('cabecalho.php'); ?>
<?php 
error_reporting(0); 
$clickx = $_GET['clickx'];
//echo "<BR>inicia orcamento";
/*
$vaii=0;
if (isset($vaii)) { echo "exite ";  }
 else { 	echo "nao existe"; }
*/
//
//$empresax="004";
$server = $_SERVER['SERVER_NAME']; 
$endereco = $_SERVER ['REQUEST_URI'];
// muito importante 
//echo "<BR><BR>http://" . $server ." Endereco ". $endereco;
//
if ($endereco=="/central/index.php?pagina=link1") { $empresax="001" ; $ordemx=2 ; $consdt1='2012-02-10'; $consdt2='2012-02-10'; } else { $ordemx=$_GET['ordem'] ; $empresax=$_GET['empresax'] ; $consdt1=$_GET['dt1'] ; $consdt2=$_GET['dt2'] ;}
//temporario
 $consdt1="2012-01-01";
 $consdt2="2012-05-25";

if($clickx=="ok"){
   require_once('..\cabecalho.php');   // Tive que inserir essa linha pq perdia o cabecallho
   // $empresax =$_GET['selex'];
    // ver esse o porqur include('includes/classes/pag_manu002.php');
	//echo "<BR>primeiro if dispara um include em includes/classes/pag_manu001<BR>";
	include('includes/classes/pag_manu001.php');
	//echo "<BR> volta do pag_manu";
	$obj = new artistas(); 
	//$ordem=2; recebe do formulario 
	$ordemx =$_GET['ordem'];
	//echo "<BR> OPCAO 1    lllll<BR><BR><BR>llll<BR>lllll ".$ordemx . "veja o resultado empresa ".$empresax;
	   
	$obj->selecionar($ordemx,$empresax,$consdt1,$consdt2);
	$obj->paginacao('30');
	}
else
   {
   //echo "<BR> s e g u n d o    if dispara um include em includes/classes/pag_manu001<BR>";
    // echo "<BR><BR> Talvez nao use essa rotina 0001\mostar_dados linha 38 <BR><BR>";
	include('includes/classes/pag_manu001.php');
	//echo "<BR> volta do includei segundo if";
	$obj = new artistas(); 
	$obj->selecionar($ordemx,$empresax,$consdt1,$consdt2);
	$obj->paginacao('30');
	}
?>

<?php
//ECHO " <BR>NOTEI QUE ELE NAO ACUMA VALOR TERA QUE FAZER PASSAGEM NOVAMENTE";
//echo "<BR> ordem ".$ordemtemp;

	    	  ?>
      <BR> <center> <a href='/central/index.php'>Finaliza sess�o abaixo</a> | Ordenar por: 
        <a href='/central/index.php?pagina=link1&pg=1&empresax=<?php echo $empresax; ?>&ordem=2'> No. Req. </a> | 	
	    <a href='/central/index.php?pagina=link1&pg=1&ordem=1&empresax=<?PHP echo $empresax ;?>'> Data Req.  </a> | 	
   	    <a href='/central/index.php?pagina=link1&pg=1&ordem=3&empresax=<?PHP echo $empresax ;?>'> Num.NF </a> | 	
   	    <a href='/central/index.php?pagina=link1&pg=1&ordem=4&empresax=<?PHP echo $empresax ;?>'> Cod. Cliente</a> 
    <!-- ?php echo $teste; echo $empresax. " 2222" ;  ?>< ?php echo $teste; ?> -->
      <form action="/central/0001/mostra_dados.php" method="GET">
<!-- form action="/central/index.php?pagina=link1&pg=1" method="GET" -->
  <table width="80%" border="0" align="center" cellpadding="0" cellspacing="0" bordercolor="2" bgcolor="#CCCCCC">
           <tr>
             <td width="30%"><label>
               Empresa
                 <select name="empresax" id="empresax">
                   <option value="1000">Todas</option>
                   <option value="001">001-Cometa</option>
                   <option value="002">002-Galactica</option>
                   <option value="003">003-Motonew</option>
                   <option value="006">006-Pandora</option>
                 </select>
                 
                 </label></td>
		         <td width="10%"><div align="left">Dt Inicial
			     <td><input name="dt1" type="text" id="dt1" size="15" maxlength="15" />
			     <td width="8%"><div align="left">Dt Final
			     <td><input name="dt2" type="text" id="dt2" size="15" maxlength="15" />
		        </div></td>
		        <td><div align="center">
				  <input type="hidden" name='clickx' value='ok'>
				  <input type="hidden" name='ordem' value='<?php echo $ordemx ;?>'>
				  <input type="hidden" name='empresay' value='<?php echo $empresax ;?>'>		  
				  
			     <input type="submit" value="Pesquisar" />
		        </div></td> 
           </tr>
         </table>
  </form> 


<!-- fim do codigo novo -->


<?php
echo "<center>";
$obj->pagfirst($ordemx,$empresax);
$obj->pagprev($ordemx,$empresax);
$obj->paginar($ordemx,$empresax);
$obj->pagnext($ordemx,$empresax);
$obj->paglast($ordemx,$empresax);

echo "</center>";
//echo "<font size='22'>";
echo "<center><table border=0 >";
		//echo "<tr bgColor='#CCCCCC'><td>"."Empresa"."<td>"."  N. Req.  "."<td>"; if ($ordemx==1) { echo "<Font color='red'>Data </font> ";}  else { echo "Data"; }; echo "<td>"." C. Cliente"."<td>"."Num. NF"."<td>"."Data NF"."<td>"."  UF  "."<td>"." 2 Data NF 2 "."<td>"." N.Controle"."<td>"." CFOP"."<td>"." Editar"."<td>"."Excluir"."</tr>";	
		echo "<tr bgColor='#CCCCCC'><td>"."Empresa"."<td>"; if ($ordemx==2) { echo "<Font color='red'>&nbsp&nbspN. Req.&nbsp&nbsp </font> ";}  else { echo "N. Req"; }; echo "<td>"; if ($ordemx==1) { echo "<Font color='red'>&nbsp&nbsp Dt Req &nbsp&nbsp </font> ";}  else { echo "&nbsp&nbsp Dt Req &nbsp&nbsp"; }; echo "<td>" ; if ($ordemx==4) { echo "<Font color='red'>&nbsp Cod Cliente &nbsp </font> ";}  else { echo "&nbsp Cod Cliente &nbsp"; }; echo "<td>" ;   if ($ordemx==3) { echo "<Font color='red'>&nbsp N Fiscal &nbsp </font> ";}  else { echo "&nbsp N Fiscal &nbsp"; };  echo "<td>"."&nbspData NF&nbsp"."<td>"."&nbsp  UF &nbsp "."<td>"." N.Controle"."<td>"." VENDEDOR "."<td>"." Editar"."<td>"."Excluir"."</tr>";	
		$tamfont=3;
		$volta=1;
		$cortab='#ffffff';
while($linha= mysql_fetch_object($obj->rs)){ 
		echo "<tr bgcolor='$cortab'><td align=center><font size='$tamfont'>".$linha->EMPRESA.
		"</font><td><font size='$tamfont'>".$linha->NUMREQ."</font> <td><font size='$tamfont'>".date('d/m/y',strtotime($linha->DATREQ))."</font>".
		//"<td><font size='$tamfont'>".implode('/',array_reverse(explode('-',$linha->CODCLI)))."</font>".
		
		"<td><font size='$tamfont' align=center>".$linha->CODCLI."</font>"."<td><font size='$tamfont'>".$linha->NUMNF."</font>".
    	"<td><font size='$tamfont'>".date('d/m/y',strtotime($linha->DATANF))."</font>"."<td align=center><font size='$tamfont'>".$linha->SIGLA."</font>".
		"<td><font size='$tamfont'>".$linha->NUMCON."</font>"."<td align=center><font size='$tamfont'>".$linha->CODREP."</font>".
		"<td><A HREF='./0001/conpedido.php?quem=$linha->NUMREQ'>Consulta</a>";
		//"<td align='center'>"."<A HREF='uf_icms/excluir.php?quem=$linha->id'><img src='imagem/lixeira.png' height='22' width='22'></A>"."</tr>";
		/* "<td align='center'><A HREF='./uf_icms/form_altera_dados.php?quem=$linha->id'><img src='imagem/editar1.png' height='28' width='32'></a>"."<td align='center'>"."<A HREF='uf_icms/excluir.php?quem=$linha->id'><img src='imagem/lixeira.png' height='22' width='22'></A>"."</tr>";	*/
		//$data = implode("/",array_reverse(explode("-",$data)))
		//	"<td><font size='$tamfont'>".$linha->DATANF."</font>".
		//		"<td><font size='$tamfont'>".$linha->SIGLA."</font>".
				
		if ($volta==1) {
		    $cortab='#ffffcc';
			$volta=0;}
		else {
		   $cortab='#ffffff';
		    $volta=$volta+1;		
		}
}
echo "</table></center>";
echo "</font>";

//include('rodape.php');
 ?>

