<?php
$bancox='central1';
$tabelax='categoria';
$conexao = mysql_connect ("mysql18.redehost.com.br","usuariorcentral","usuariocentral");
if (!$conexao) {
	die('Conexao nao Efeutada Falha: ' . mysql_error());  }
$banco_ok = mysql_select_db($bancox,$conexao);  // mysql 5.0 
if (!$banco_ok) {
	 die ('Erro na abertura de banco de dados: ' . mysql_error());   }
$quem=$_GET['quem'];
$consulta = "select * from categoria where id='$quem' ";
$resultado =mysql_query ($consulta,$conexao);
$linha = mysql_fetch_row ($resultado);
include('../cabecalho.php'); 
?>


<center>Altera��o de Dados</center>
<center><a href="../cadastro.php">Tela de Cadastro Geral</a> | <a href="../cadastro.php?pagina=link6" class="link6">Exibe consulta</a></center>
<form name="form" method="post" action="altera_dados.php">
  <table width="428" border="1" align="center">
    <tr>
      <td width="138">Codigo:</td>
      <td width="274"><input name="txtcampo1" type="text" id= "txtcampo1" size="40" value="<?php echo $linha[1];?>" /></td>
    </tr>
    <tr>
      <td>Opera&ccedil;&atilde;o: </td>
      <td><input name="txtcampo2" type="text" id= "txtcampo2" size="40" value="<?php echo $linha[2];?>" /></td>
    </tr>
    <tr>
      <td>Tipo:</td>
      <td><input name="txtcampo3" type="text" id= "txtcampo3" size="40" value="<?php echo $linha[3];?>" /></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><div align="center">
        <input type ="submit" name="submit" value="Salvar" />
        <input name="reset" type="reset" id="reset" value="limpar" />
      </div></td>
    </tr>
  </table>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p><BR>
    <BR>
    <input type="hidden" name="codigo" value="<?php echo $linha[0];?>">
<BR>
  </p>
<?php include('../rodape.php'); ?>
</form>
