<?php if (!isset($_SESSION)) { session_start();}?>
<?PHP
//echo "<BR> --xx--- > Acessando 0001\classe\Conexao_opera < ---xx-----<BR>";
//$_SESSION['cntip']=1; //temporario
//ECHO "<br> INICIA 0001\INCLUDES\CLASSES\CONEXAO_OPERA VALOR DE SESSAO ".$_SESSION['cntip'];
if ($_SESSION['cntip']==1) {
  //conexao loca
  //echo "<BR><BR><BR> local <BR><BR><BR>";
  class conexao{
        
           public $servidor="localhost";
    	   public $login="root";
    	   public $senha="";
    	   public $banco="bdcentral";     //  "central1"; 
		   public function conexao(){
		   mysql_connect($this->servidor,$this->login,$this->senha);	
		  }
     }
  }
else
  { 
  // conexao remota
  //echo "<BR><BR><BR> REMOTA <BR><BR><BR>";
  class conexao{
   		  public $servidor="mysql18.redehost.com.br";
  		  public $login="usuariorcentral";
  		  public $senha="usuariocentral";
		  public $banco="central1";
		  public function conexao(){
	   	  mysql_connect($this->servidor,$this->login,$this->senha);	
		  }
     }
}
//echo "<BR><BR><BR>  --xx--- > Acessando fim da rotina conxao . < ---xx-----<BR>";
?> 