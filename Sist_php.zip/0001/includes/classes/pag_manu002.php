<?php error_reporting(0); ?>
<?php  session_start(); ?>
<?php header('Content-Type: text/html; charset=ISO-8859-1'); ?>
<?php 
  echo "<BR> chegou no mostra  2  a.b.c."; 
 require('\classes\conexao_opera.php');
 //require('conexao_opera.php');
  echo "<BR> 38 fim do if a.b.c."; 
class artistas{

	public $rs;
	public $rstotal;
	public $sql;
	public $limit;
	public $rsporpg;
	public $numpags;
	//public $ordemx;

	public function __construct(){
			$this->conn = new conexao();
			// echo "<BR> LINHA 58";

	}
	
	public function selecionar($ordemx,$empresa1){
		//echo "<BR> LINHA 40";
	   $ordemxy = $ordemx;
	   $empresa1 = $empresa1;
	   echo "<br><center> <a href='..\index.php'>Finaliza sess�o abaixo</a> | Ordenar por: ";
       echo " <a href='?pagina=link1&pg=1&ordem=2&clickx=ok'> No. Req. </a> | ";	
	   echo " <a href='?pagina=link1&pg=1&ordem=1&clickx=ok'> Data Req.  </a> | ";	
   	   echo " <a href='..\0001\?pagina=link1&pg=1&ordem=3&clickx=ok'> Num.NF </a> | ";	
   	   echo " <a href='..\0001\?pagina=link1&pg=1&ordem=4&clickx=ok'> Cod. Cliente</a> ";	
	   
	  ?> 

	<?php   
	   
	   $ordemxy = $_GET['ordem'];
	   if (isset($ordemxy)) {
		  if ($ordemxy == 1) {
			 $ordemx='DATREQ';  } // $ordem =codigo
		  elseif ($ordemxy == 2) {   
			   $ordemx='NUMREQ'; }
		  elseif ($ordemxy == 3) {   
			   $ordemx='NUMNF'; }
    	  elseif ($ordemxy == 4) {   
			   $ordemx='CODCLI'; }
			}   
		else {
			   // Nao existe vai no else e criar categria
			   $ordemx='NUMREQ'; 
			   }
		if (isset($empresa1)) {
		   if ($empresa1=="1000") { 
		      $selempx="(EMPRESA='001' or EMPRESA='002' or EMPRESA='003')";
		   }
		   else {
		     $selempx="EMPRESA='".$empresa1."'";}
		  //echo "existe".$selemp; 	
		}

			   //date('d/m/y',strtotime($linha->DATREQ)    --    date('d/m/y',strtotime($linha->DATANF))
			   $data1='2012-02-01';
			   $data2='2012-02-28';
			   
			   //$this->sql = "select * from test_prefixrequis where (EMPRESA='002' and DATANF>= '".$data1."' and DATANF<= '".$data2."')  order by $ordemx asc";
			   $this->sql = "select * from test_prefixrequis where (".$selempx."and DATANF>= '".$data1."' and DATANF<= '".$data2."')  order by $ordemx asc";
			  
			// ok funcionando $this->sql = "select * from test_prefixrequis where (EMPRESA='002' and DATANF>= '2012-01-30' and DATANF<= '2012-03-15')  order by $ordemx asc";
			 //$this->sql = "select * from test_prefixrequis where (EMPRESA='003' and (DATANF BETWEEN $dataMySQL2 AND $dataMySQL3))  order by $ordemx asc";
			 
            //$this->sql = "select * from test_prefixrequis where (EMPRESA='003' and STR_TO_DATE('DATANF', '%d/%m/%Y')>= $dataMySQL2 )  order by $ordemx asc";
	        //$this->sql = "select * from test_prefixrequis order by $ordemx asc";
			$this->rs = mysql_db_query($this->conn->banco,$this->sql);
			$this->rstotal = mysql_num_rows($this->rs);
		}	
		
		public function paginacao($rsporpg){
			$this->rsporpg=$rsporpg;// seta total de registros por pagina
			$this->numpags = ceil($this->rstotal/$this->rsporpg);
			$inicio = ($_GET['pg']-1)*$this->rsporpg;
			//$inicio = '?pagina=link7&'.($_GET['pg']-1)*$this->rsporpg;
			if($_GET['pg']){
				$this->limit = $this->sql." limit $inicio, $this->rsporpg";
			}else{
				$this->limit = $this->sql." limit 1, $this->rsporpg";
			}
			$this->rs = mysql_db_query($this->conn->banco,$this->limit );	
		}	
		public function paginar(){
		    $i=1;
			while ($i <= $this->numpags){
			//echo " <a href='?pg=$i'> $i </a> ";

			if (isset($_GET['ordem'])) { 
	            $nn = $_GET['ordem'];
			 }
			 else { 
			   $nn=1;}
			echo " <a href='?pagina=link1&pg=$i&ordem=$nn'> $i </a> ";
			$i++;	
				}	
		}
		public function pagprev(){
			if($_GET['pg']){
				if($_GET['pg']!=1){
				$anterior = $_GET['pg']-1;
				//echo " <a href='?pg=$anterior'> < </a> ";
				if (isset($_GET['ordem'])) { 
	               $nn = $_GET['ordem'];
			     }
			    else { 
			       $nn=1;}
				echo " <a href='?pagina=link1&pg=$anterior&ordem=$nn'> < </a> ";
				}		
			}				
		}
		public function pagnext(){
			if($_GET['pg']){
				if($_GET['pg']!=$this->numpags){
				$proximo = $_GET['pg']+1;
				//echo " <a href='?pg=$proximo'> > </a> ";
				if (isset($_GET['ordem'])) { 
	               $nn = $_GET['ordem'];
			     }
			    else { 
			       $nn=1;}
				echo " <a href='?pagina=link1&pg=$proximo&ordem=$nn'> > </a> ";			
				}
			}		
		}
		
		public function pagfirst(){
				//echo " <a href='?pg=1'> << </a> ";

				if (isset($_GET['ordem'])) { 
	               $nn = $_GET['ordem'];
			     }
			    else { 
			       $nn=1;}
				echo " <a href='?pagina=link1&pg=1&ordem=$nn'> << </a> ";	
		}
		public function paglast(){
				//echo " <a href='?pg=$this->numpags'> >></a> ";
				if (isset($_GET['ordem'])) { 
	               $nn = $_GET['ordem'];
			     }
			    else { 
			       $nn=1;}
     			echo " <a href='?pagina=link1&pg=$this->numpags&ordem=$nn'> >> </a> ";	
		}
}

?>
