<?php error_reporting(0); ?>
<?php  session_start(); ?>
<?php header('Content-Type: text/html; charset=ISO-8859-1'); ?>
<?php 
	 if($clickx=="ok"){
	    echo "<br> ----> ja existe e  abre o banco linha pag_manu002 12";
	    //require('E:\WAMP\WWW\CENTRAL\classes\conexao_opera.php');
		//echo "<br> agora existe e nao abre o banco deccccccccccccccccccccccc";
       require('conexao_opera.php');
	  //require('\classes\conexao_opera.php');
	   echo "<br> ----> Abre conexao ";
	   }
	?>
   

<?php 
   echo "<BR>Criando classes opcao pesquisar"; 
class artistas{

	public $rs;
	public $rstotal;
	public $sql;
	public $limit;
	public $rsporpg;
	public $numpags;
	//public $ordemx;

	public function __construct(){
			$this->conn = new conexao();
			echo "<BR> LINHAsssssss 58";
	}
	
	public function selecionar($ordemx){
		echo "<BR> LLLINHA 40";
	   $ordemxy = $ordemx;
	   echo "<br><center> <a href='../index.php'>Finaliza sess�o abaixo</a> | Ordenar por: ";
       echo " <a href='../?pagina=link1&pg=1&ordem=2'> No. Req. </a> | ";	
	   echo " <a href='?pagina=link1&pg=1&ordem=1'> Data Req.  </a> | ";	
   	   echo " <a href='../?pagina=link1&pg=1&ordem=3'> Num.NF </a> | ";	
   	   echo " <a href='../?pagina=link1&pg=1&ordem=4'> Cod. Cliente</a> ";	
	   		echo "teste linha 41 ";
   ?> 
	  
<!--form action="pag_manu001.php" method="get" 
	<form action="0001/INCLUDES/CLASSES/pag_manu001.php?clickx=ok" method="POST">

  <table width="80%" border="0" align="center" cellpadding="0" cellspacing="0" bordercolor="2" bgcolor="#CCCCCC">
           <tr>
             <td width="8%">Pesquisa: </td>
             <td width="26%"><label>
               Empresa
                 <select name="select" id="select">
                   <option value="1000">Todas</option>
                   <option value="1">Cometa</option>
                   <option value="2">Galactica</option>
                   <option value="3">Motonew</option>
                   <option value="4">Pandora</option>
                 </select>
                 
                 </label></td>
		         <td width="52%"><div align="left">Orc. Inicial
			     <input name="data1" type="text" id="data1" size="15" maxlength="15" />
			Orc. Final
			     <input name="data2" type="text" id="data2" size="15" maxlength="15" />
		        </div></td>
		        <td width="5%">&nbsp;</td>
		        <td width="13%"><div align="center">
			     <input type="submit" value="Pesquisar" />
		        </div></td> 
           </tr>
         </table>
  </form>       

-->
	<?php 
			echo "teste ordem linha 76";  
	   $ordemxy = $_GET['ordem'];
	   if (isset($ordemxy)) {
		  if ($ordemxy == 1) {
			 $ordemx='DATREQ';  } // $ordem =codigo
		  elseif ($ordemxy == 2) {   
			   $ordemx='NUMREQ'; }
		  elseif ($ordemxy == 3) {   
			   $ordemx='NUMNF'; }
    	  elseif ($ordemxy == 4) {   
			   $ordemx='CODCLI'; }
			}   
		else {
			   // Nao existe vai no else e criar categria
			   $ordemx='NUMREQ'; 
			   }
			   //date('d/m/y',strtotime($linha->DATREQ)    --    date('d/m/y',strtotime($linha->DATANF))
			   $data1='2012-02-01';
			   $data2='2012-02-28';
			   
			   $this->sql = "select * from test_prefixrequis where (EMPRESA='002' and DATANF>= '".$data1."' and DATANF<= '".$data2."')  order by $ordemx asc";
			  
			// ok funcionando $this->sql = "select * from test_prefixrequis where (EMPRESA='002' and DATANF>= '2012-01-30' and DATANF<= '2012-03-15')  order by $ordemx asc";
			 //$this->sql = "select * from test_prefixrequis where (EMPRESA='003' and (DATANF BETWEEN $dataMySQL2 AND $dataMySQL3))  order by $ordemx asc";
			 
            //$this->sql = "select * from test_prefixrequis where (EMPRESA='003' and STR_TO_DATE('DATANF', '%d/%m/%Y')>= $dataMySQL2 )  order by $ordemx asc";
	        //$this->sql = "select * from test_prefixrequis order by $ordemx asc";
			$this->rs = mysql_db_query($this->conn->banco,$this->sql);
			$this->rstotal = mysql_num_rows($this->rs);
					echo "teste linha 103  ";
		}	
		
		public function paginacao($rsporpg){
		    echo $this->rsporpg;
			echo "testexx ";
			$this->rsporpg=$rsporpg;// seta total de registros por pagina
			$this->numpags = ceil($this->rstotal/$this->rsporpg);
			$inicio = ($_GET['pg']-1)*$this->rsporpg;
			//$inicio = '?pagina=link7&'.($_GET['pg']-1)*$this->rsporpg;
			if($_GET['pg']){
				$this->limit = $this->sql." limit $inicio, $this->rsporpg";
			}else{
				$this->limit = $this->sql." limit 1, $this->rsporpg";
			}
			$this->rs = mysql_db_query($this->conn->banco,$this->limit );	
			echo "yyytesteyyy ";
		}	
		public function paginar(){
		    $i=1;
			while ($i <= $this->numpags){
			//echo " <a href='?pg=$i'> $i </a> ";

			if (isset($_GET['ordem'])) { 
	            $nn = $_GET['ordem'];
			 }
			 else { 
			   $nn=1;}
			echo " <a href='?pagina=link1&pg=$i&ordem=$nn'> $i </a> ";
			$i++;	
				}	
		}
		public function pagprev(){
			if($_GET['pg']){
				if($_GET['pg']!=1){
				$anterior = $_GET['pg']-1;
				//echo " <a href='?pg=$anterior'> < </a> ";
				if (isset($_GET['ordem'])) { 
	               $nn = $_GET['ordem'];
			     }
			    else { 
			       $nn=1;}
				echo " <a href='?pagina=link1&pg=$anterior&ordem=$nn'> < </a> ";
				}		
			}				
		}
		public function pagnext(){
			if($_GET['pg']){
				if($_GET['pg']!=$this->numpags){
				$proximo = $_GET['pg']+1;
				//echo " <a href='?pg=$proximo'> > </a> ";
				if (isset($_GET['ordem'])) { 
	               $nn = $_GET['ordem'];
			     }
			    else { 
			       $nn=1;}
				echo " <a href='?pagina=link1&pg=$proximo&ordem=$nn'> > </a> ";			
				}
			}		
		}
		
		public function pagfirst(){
				//echo " <a href='?pg=1'> << </a> ";

				if (isset($_GET['ordem'])) { 
	               $nn = $_GET['ordem'];
			     }
			    else { 
			       $nn=1;}
				echo " <a href='?pagina=link1&pg=1&ordem=$nn'> << </a> ";	
		}
		public function paglast(){
				//echo " <a href='?pg=$this->numpags'> >></a> ";
				if (isset($_GET['ordem'])) { 
	               $nn = $_GET['ordem'];
			     }
			    else { 
			       $nn=1;}
     			echo " <a href='?pagina=link1&pg=$this->numpags&ordem=$nn'> >> </a> ";	
					echo " iiiiii fim 1  ";
		}
			
}

//} // fechando o if do ok
?>
