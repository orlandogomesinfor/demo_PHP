<?php
class conexao{
      //local
	  /*
       private $servidor="localhost";
	   private $login="root";
	   private $senha="";
	   private $banco="central"; */

 		public $servidor="mysql18.redehost.com.br";
		public $login="usuariorcentral";
		public $senha="usuariocentral";
		public $banco="central1";
		
		public function conexao(){
			mysql_connect($this->servidor,$this->login,$this->senha);	
		}
		
	
}
?> 