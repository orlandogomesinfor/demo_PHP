<?php error_reporting(0); ?>
<?php  session_start(); ?>
<?php header('Content-Type: text/html; charset=ISO-8859-1'); ?>
<?php 
require($_SESSION['con2']);
class artistas{

	public $rs;
	public $rstotal;
	public $sql;
	public $limit;
	public $rsporpg;
	public $numpags;
	//public $ordemx;

	public function __construct(){
			$this->conn = new conexao();
	}
	// detalhe o { dessa funcao e fechado bem abaixo
	public function selecionar($ordemx,$empresax,$consdt1,$consdt2){
	   $ordemxy   = $ordemx;
	   $empresaxy = $empresax;
	   //$data1='2012-02-01';
	   //$data2='2012-02-28';
	   $data1=$consdt1;
	   $data2=$consdt2;
	   //echo $data1;
	   //echo $data2;
	
	   $ordemxy = $_GET['ordem'];
	   if (isset($ordemxy)) {
		  if ($ordemxy == 1) {
			 $ordemx='DATREQ';  } // $ordem =codigo
		  elseif ($ordemxy == 2) {   
			   $ordemx='NUMREQ'; }
		  elseif ($ordemxy == 3) {   
			   $ordemx='NUMNF'; }
    	  elseif ($ordemxy == 4) {   
			   $ordemx='CODCLI'; }
			}   
		else {
			   // Nao existe vai no else e criar categria
			   $ordemx='NUMREQ'; 
		   }
		// criterio de data date('d/m/y',strtotime($linha->DATREQ)    --    date('d/m/y',strtotime($linha->DATANF))
   
		 if ($empresaxy=="1000") {
		    //$this->sql = "select * from test_prefixrequis where (DATANF>= '".$data1."' and DATANF<= '".$data2."')  order by $ordemx asc";
			$this->sql = "select * from requis where (DATANF>= '".$data1."' and DATANF<= '".$data2."')  order by $ordemx asc";
			//$this->sql = "select * from test_prefixrequis where (date_format(DATANF,?%d/%m/%y?)>= '".$data1."' and (date_format(DATANF,?%d/%m/%y?)<= '".$data2."')  order by $ordemx asc";
		   }
		else {
     	   $this->sql = "select * from requis where (EMPRESA='".$empresaxy."' and DATANF>= '".$data1."' and DATANF<= '".$data2."')  order by $ordemx asc";
	        }		   
			   //linha ok 041013 $this->sql = "select * from test_prefixrequis where (EMPRESA='002' and DATANF>= '".$data1."' and DATANF<= '".$data2."')  order by $ordemx asc";
			  
			// ok funcionando $this->sql = "select * from test_prefixrequis where (EMPRESA='002' and DATANF>= '2012-01-30' and DATANF<= '2012-03-15')  order by $ordemx asc";
			//$this->sql = "select * from test_prefixrequis where (EMPRESA='003' and (DATANF BETWEEN $dataMySQL2 AND $dataMySQL3))  order by $ordemx asc";
            //$this->sql = "select * from test_prefixrequis where (EMPRESA='003' and STR_TO_DATE('DATANF', '%d/%m/%Y')>= $dataMySQL2 )  order by $ordemx asc";
			$this->rs = mysql_db_query($this->conn->banco,$this->sql);
			$this->rstotal = mysql_num_rows($this->rs);
		}	
		
		public function paginacao($rsporpg){
			$this->rsporpg=$rsporpg;// seta total de registros por pagina
			$this->numpags = ceil($this->rstotal/$this->rsporpg);
			$inicio = ($_GET['pg']-1)*$this->rsporpg;
			//$inicio = '?pagina=link7&'.($_GET['pg']-1)*$this->rsporpg;
			if($_GET['pg']){
				$this->limit = $this->sql." limit $inicio, $this->rsporpg";
			}else{
				$this->limit = $this->sql." limit 1, $this->rsporpg";
			}
			$this->rs = mysql_db_query($this->conn->banco,$this->limit );	
		}	
		public function paginar($ordemx,$empresax){
			$ordemxy   = $ordemx;
	        $empresaxy = $empresax;
		    $i=1;
			while ($i <= $this->numpags){
			//echo " <a href='?pg=$i'> $i </a> ";

			if (isset($_GET['ordem'])) { 
	            $nn = $_GET['ordem'];
			 }
			 else { 
			   $nn=1;}
			//echo " <a href='?pagina=link1&pg=$i&ordem=$nn'> $i </a> ";
			echo " <a href='?pagina=link1&pg=$i&ordem=$ordemxy&empresax=$empresaxy'> $i </a> ";
			$i++;	
				}	
		}
		public function pagprev($ordemx,$empresax){
			$ordemxy   = $ordemx;
	        $empresaxy = $empresax;
			if($_GET['pg']){
				if($_GET['pg']!=1){
				$anterior = $_GET['pg']-1;
				//echo " <a href='?pg=$anterior'> < </a> ";
				//if (isset($_GET['ordem'])) { 
	             //  $nn = $_GET['ordem'];
			     //}
			    //else { 
			     //  $nn=1;}
				echo " <a href='?pagina=link1&pg=$anterior&ordem=$ordemxy&empresax=$empresaxy'> < </a> ";
				}		
			}				
		}
		public function pagnext($ordemx,$empresax){
			$ordemxy   = $ordemx;
	        $empresaxy = $empresax;
			if($_GET['pg']){
				if($_GET['pg']!=$this->numpags){
				$proximo = $_GET['pg']+1;
				//echo " <a href='?pg=$proximo'> > </a> ";
				//if (isset($_GET['ordem'])) { 
	            //   $nn = $_GET['ordem'];
			    // }
			    //else { 
			    //   $nn=1;}
				//echo " <a href='?pagina=link1&pg=$proximo&ordem=$nn&empresax=006'> > </a> ";			
				echo " <a href='?pagina=link1&pg=$proximo&ordem=$ordemxy&empresax=$empresaxy'> > </a> ";			
				}
			}		
		}
		
		public function pagfirst($ordemx,$empresax){
			$ordemxy   = $ordemx;
	        $empresaxy = $empresax;
			//echo " <a href='?pg=1'> << </a> ";
				//if (isset($_GET['ordem'])) { 
	             //  $nn = $_GET['ordem'];
			     //}
			    //else { 
			     //  $nn=1;}
				//echo " <a href='?pagina=link1&pg=1&ordem=$nn'> << </a> ";	
				echo " <a href='?pagina=link1&pg=1&ordem=$ordemxy&empresax=$empresaxy'> << </a> ";	
		}
		
		
		// original    public function paglast(){
		public function paglast($ordemx,$empresax){
			   $ordemxy   = $ordemx;
	           $empresaxy = $empresax;
			   // ESSE ISSET PODE SER REMOVIDO
				//if (isset($_GET['ordem'])) { 
					//echo " existe ";	
	            //   $nn = $_GET['ordem'];
				   //$ep = $_GET['empresay'];
			     //}
			    //else { 
				//echo "nao existe";
			     //  $nn=1;
			       //$ep = $_GET['empresay'];
				   // original echo "<BR><BR> ordem ".$nn."outro teste hh ".$empresaxy."teste ordem ".$ordemxy;
				  // echo "<BR><BR> ooo jhjh ".$valor.$empresaxy."oo o o o ordem ".$nn."outro teste ".$empresaxy."teste ordem ".$ordemxy;
				   //}
				   
     			// original echo " <a href='?pagina=link1&pg=$this->numpags&ordem=$nn'> >> </a> ";	
				//echo "<a href='?pagina=link1&pg=$anterior&ordem=$nn&empresax=006'> < </a> ";
				//echo "<BR>".$ordemxy."<BR>".$empresaxy."<BR>";
				echo "<a href='?pagina=link1&pg=$this->numpags&ordem=$ordemxy&empresax=$empresaxy'> >> </a> ";	
		}
}
	 
?>
