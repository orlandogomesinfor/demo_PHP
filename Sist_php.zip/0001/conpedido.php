<?php header('Content-Type: text/html; charset=ISO-8859-1'); ?>
<?php error_reporting(0); ?>
<?php  session_start(); ?>
<?php header('Content-Type: text/html; charset=ISO-8859-1'); ?>
<?php
//$quem=$_GET['quem']; recebe requisicao
include('includes/classes/conexao_opera.php');
//echo "<BR> em conpedido volta do includes/classes/conexao_opera.php";
include('../cabecalho.php'); 
//Acessando banco de dados com criterio

class artis{
   /*	public $rs;
	public $rstotal;
	public $sql;
	public $limit;
	public $rsporpg;
	public $numpags; */
    public $rsdetalhe;
	public $rstotal_dt;
	public $ordemxy;
	public $ordemx;
	public $sqlitem;
	public $limit;
	public $rsporpg;
	public $numpags;
	public $quemx; // recebe o numero da requisicao

	public function __construct(){
			$this->conn = new conexao();
			 //echo "<BR> <BR> EM conpedido lINHA 31";
	}
		
		public function pagi_deta($rsporpg){
	       // echo "<BR> ----- funcao pagi_deta  33 ---------<BR>";	
		   //echo "<BR> <BR> EM conpedido lINHA 36";
			$this->rsporpg=$rsporpg;// seta total de registros por pagina
			$this->numpags = ceil($this->rstotal_dt/$this->rsporpg);
			$inicio = ($_GET['pg']-1)*$this->rsporpg;
			if($_GET['pg']){
				$this->limit = $this->sqlitem." limit $inicio, $this->rsporpg";
			}else{
				$this->limit = $this->sqlitem." limit 1, $this->rsporpg";
			}
			$this->rsdetalhe = mysql_db_query($this->conn->banco,$this->limit );	
		}	

	public function selepedido($ordemx){
	    //echo "<BR> ----- funcao ordem x47 ---------<BR>";
	   // receber do formulario $ordemxy = $_GET['ordem'];
	   //$ordemxy = 2 ;
 	   $ordemxy = $ordemx;
	  // echo $ordemxy." ffffffffffffffff";
	  	if (isset($ordemxy)) {
		  if ($ordemxy == 1) {
			 $ordemx='DATREQ'; 
	   		 } // $ordem =codigo
		  elseif ($ordemxy == 2) {   
			   $ordemx='NUMREQ'; }
		  elseif ($ordemxy == 3) {   
			   $ordemx='NUMNF'; }
    	  elseif ($ordemxy == 4) {   
			   $ordemx='CODCLI'; }
		}   
		else {
			   // Nao existe vai no else e criar categria
			   $ordemx='NUMREQ'; 
			   }
		 }
 
	public function sele_deta($ordemx,$quemx){
		//echo " <BR> --------- funcao sele_deta 68------------ <br>";
	   $ordemxy = $ordemx;
	   echo "<br><center> <a href='..\index.php'>Finalizar sess�o</a> | ";
       echo " <a href='mostra_dados.php'> Volar tela </a> | ";	
	   echo " <a href='?pagina=link1&pg=1&ordem=1'> Excluir </a> | ";	
   	   echo " <a href='?pagina=link1&pg=1&ordem=3'> Faturar </a> | ";	
   	   echo " <a href='?pagina=link1&pg=1&ordem=4'> Imprimir </a> ";	
	  ?> 

	<?php   
	   
	   $ordemxy = $_GET['ordem'];
	   if (isset($ordemxy)) {
		  if ($ordemxy == 1) {
			 $ordemx='DATREQ';  } // $ordem =codigo
		  elseif ($ordemxy == 2) {   
			   $ordemx='NUMREQ'; }
		  elseif ($ordemxy == 3) {   
			   $ordemx='NUMNF'; }
    	  elseif ($ordemxy == 4) {   
			   $ordemx='CODCLI'; }
			}   
		else {
			   // Nao existe vai no else e criar categria
			   $ordemx='NUMREQ'; 
			   }
			   //date('d/m/y',strtotime($linha->DATREQ)    --    date('d/m/y',strtotime($linha->DATANF))
			   $data1='2012-02-01';
			   $data2='2012-02-28';
			   $quemy = $_GET['quem'];  // recebe o numrero da requis
			   //$this->sqlitem = "select * from test_prefixmovto where (numreq=26935)  order by $ordemx asc";
			   // ok funciona $this->sqlitem = "select * from test_prefixmovto where numreq=".$quemy."  order by numreq asc";

			  
			  $this->sqlitem = "select test_prefixmovto.numreq,test_prefixmovto.codmat,test_prefixmovto.qtdeenv,test_prefixmovto.qtdenf,test_prefixmovto.vunit,test_prefixmovto.vunitnf,test_prefixmovto.codcli,
				test_prefixmaterial.descricao,test_prefixmaterial.unidade,test_prefixmaterial.ean,test_prefixmaterial.pesobr    from test_prefixmovto,test_prefixmaterial where numreq=".$quemy." order by numreq asc";
			  
			  
			  
			  
			  
			  
			  
			// ok funcionando $this->sql = "select * from test_prefixrequis where (EMPRESA='002' and DATANF>= '2012-01-30' and DATANF<= '2012-03-15')  order by $ordemx asc";
     		 //$this->sql = "select * from test_prefixrequis where (EMPRESA='003' and (DATANF BETWEEN $dataMySQL2 AND $dataMySQL3))  order by $ordemx asc";
            //$this->sql = "select * from test_prefixrequis where (EMPRESA='003' and STR_TO_DATE('DATANF', '%d/%m/%Y')>= $dataMySQL2 )  order by $ordemx asc";
	        //$this->sql = "select * from test_prefixrequis order by $ordemx asc";
			$this->rsdetalhe = mysql_db_query($this->conn->banco,$this->sqlitem);
			$this->rstotal_dt = mysql_num_rows($this->rsdetalhe);
		}	 
		 
}	// Fechando a classe	

 $obj = new artis(); 
  $ordx=1;
 $obj->selepedido($ordx);
 
 //echo "  Teste aaa ".$ordemxy." bbb valor <BR>"; 
 //echo "  Teste a12 ".$ordemx." b12 valor <BR>"; 
 $ordx=3;
 $obj->sele_deta($ordx);
 $obj->pagi_deta('20');
		 
 //$ordem=2;
 //$obj->selecionar($ordem);
 //$obj->paginacao('20');
		 
 //date('d/m/y',strtotime($linha->DATREQ)    --    date('d/m/y',strtotime($linha->DATANF))
 $data1='2012-02-01';
 $data2='2012-02-28';
			   
 //   $this->sql = "select * from test_prefixrequis where (EMPRESA='002' and DATANF>= '".$data1."' and DATANF<= '".$data2."')  order by $ordemx asc";
 //$this->rs = mysql_db_query($this->conn->banco,$this->sql);
 //	$this->rstotal = mysql_num_rows($this->rs);

// echo "<BR> data ".$data1." Final <BR><BR>";
// echo "<BR> itens do pedido <BR>";
		
 /*IF ($obj->rsdetalhe) {
	 echo "<BR> sim, agora retornou OK";
 }
 else { echo "<BR> nao "; }*/

//echo "<font size='22'>";
echo "<center><table border=0 >";
echo "<tr bgColor='#CCCCCC'><td>"."Item"."<td align='center'>"."Codigo"."<td align='center'>"." Descri��o "."<td align='center'>"."EAN"."<td>"."Peso"."<td>"." Qtde F "."<td>"." Qtde NF "."<td>"." Vl Unit. "."<td>"." Vl. NF "."<td>"." Total "."<td>"." NUMREQ "."<td>"." Editar"."<td>"."Excluir"."</tr>";	
		$tamfont=3;
		$volta=1;
		$cortab='#ffffff'; 
		$nnn=1;
while($linha= mysql_fetch_object($obj->rsdetalhe)){ 
    //$qttempo=$linha->QTDEENV+$linha->QTDEENV;
	
	echo "<tr bgcolor='$cortab'><td> ".$nnn."<td> <font size='$tamfont'>".$linha->codmat." </font> ".
	"<td><font size='$tamfont'> ".$linha->descricao ." </font>".
	"<td><font size='$tamfont'> ".$linha->ean." </font> ".
	"<td><font size='$tamfont'> ".$linha->unidade." </font> ".
	"<td><font size='$tamfont'> ".$linha->pesobr." </font> ".
	"<td><font size='$tamfont'> ".$linha->qtdeenv." </font> ".
	"<td><font size='$tamfont'> ".$linha->qtdenf." </font> ".
	"<td><font size='$tamfont'> ".$linha->vnit." </font> ".
	"<td><font size='$tamfont'> ".$linha->vunitnf." </font> ".
    "<td><font size='$tamfont'> "." vl total "." </font> ".
	"<td><font size='$tamfont'> ".$linha->numreq." </font> ";
	
	//echo "<BR> <BR> EM conpedido lINHA 177";
	
	//"<td><font size='$tamfont'>".date('d/m/y',strtotime($linha->DATreq))."</font>";

	
	
	 /* ."<td><font size='$tamfont'>".$linha->SIGLA."</font>".
   	"<td><font size='$tamfont'>".date('d/m/y',strtotime($linha->DATANF))."</font>"."<td><font size='$tamfont'>".$linha->SIGLA."</font>".
	"<td><font size='$tamfont'>".$linha->NUMCON."</font>"."<td><font size='$tamfont'>".$linha->CFOP."</font>"."<A HREF='./0001/conpedido.php?quem=$linha->id'>Consulta</a>".
	"<td align='center'><A HREF='./uf_icms/form_altera_dados.php?quem=$linha->id'><img src='imagem/editar1.png' height='28' width='32'></a>"."<td align='center'>"."<A HREF='uf_icms/excluir.php?quem=$linha->id'><img src='imagem/lixeira.png' height='22' width='22'></A>"."</tr>"; */	
			//$data = implode("/",array_reverse(explode("-",$data)))
	$nnn++;
	if ($volta==1) {
	    $cortab='#ffffcc';
		$volta=0;}
	else {
	   $cortab='#ffffff';
	    $volta=$volta+1;		
		//ECHO "<br> NAO DEU CERTO 1 ".$volta. " valor de volta<BR>";
	}
	//ECHO "<br> agora deu certo final  DEU CERTO 2 ";
}	
		

?>
</table></center>
</font>
<center><font color="blue">*** Rotina em fase de manuten��o ***</font></center>

<?php include('../rodape.php'); ?>

