<?php if (!isset($_SESSION)) { session_start();}?>
<?PHP
echo "Principal central\classes\conexao_opera.php";
if ($_SESSION['cntip']==1) {
  //conexao local
  class conexao{
	       public $servidor="localhost";
    	   public $login="root";
    	   public $senha="";
    	   public $banco="bdcentral";     //  "central1"; 
		   public function conexao(){
		   mysql_connect($this->servidor,$this->login,$this->senha);	
		  }
     }
  }
else
  { 
  // conexao remota
  class conexao{
   		  public $servidor="mysql18.redehost.com.br";
  		  public $login="usuariorcentral";
  		  public $senha="usuariocentral";
		  public $banco="central1";
		  public function conexao(){
	   	  mysql_connect($this->servidor,$this->login,$this->senha);	
		  }
     }
}
?> 