<?php require_once('Connections/cn_central.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO material (Codmat, Descricao, Unidade, Vunit, Vunit2, Vunit3, Vunit4, Vunit5, Vunit6, `Data`, Data2, Dataalt, Datalt2, Dias_comp, Estmin, Codlt, IPI, Pesobr, Vlminimo, Ean) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['Codmat'], "text"),
                       GetSQLValueString($_POST['Descricao'], "text"),
                       GetSQLValueString($_POST['Unidade'], "text"),
                       GetSQLValueString($_POST['Vunit'], "double"),
                       GetSQLValueString($_POST['Vunit2'], "double"),
                       GetSQLValueString($_POST['Vunit3'], "double"),
                       GetSQLValueString($_POST['Vunit4'], "double"),
                       GetSQLValueString($_POST['Vunit5'], "double"),
                       GetSQLValueString($_POST['Vunit6'], "double"),
                       GetSQLValueString($_POST['Data'], "text"),
                       GetSQLValueString($_POST['Data2'], "date"),
                       GetSQLValueString($_POST['Dataalt'], "text"),
                       GetSQLValueString($_POST['Datalt2'], "date"),
                       GetSQLValueString($_POST['Dias_comp'], "int"),
                       GetSQLValueString($_POST['Estmin'], "double"),
                       GetSQLValueString($_POST['Codlt'], "text"),
                       GetSQLValueString($_POST['IPI'], "double"),
                       GetSQLValueString($_POST['Pesobr'], "double"),
                       GetSQLValueString($_POST['Vlminimo'], "double"),
                       GetSQLValueString($_POST['Ean'], "text"));

  mysql_select_db($database_cn_central, $cn_central);
  $Result1 = mysql_query($insertSQL, $cn_central) or die(mysql_error());

  $insertGoTo = "sucesso_material.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style2 {color: #000000}
-->
</style>
</head>

<body>
<table width="853" border="1" align="center">
  <tr>
    <td width="69" height="23">Data: </td>
    <td width="331"><div align="center">Sistema de Gestão Empresarial </div></td>
    <td width="223">Módulo: Manutenção de Cadastro</td>
    <td width="103">Versão:1</td>
    <td width="93">Suporte</td>
  </tr>
</table>
<br />
<table width="511" border="1" align="center">
  <tr>
    <td width="79">Material</td>
    <td width="416">&nbsp;</td>
  </tr>
  <tr>
    <td>Codigo</td>
    <td>&nbsp;</td>
  </tr>
    <tr>
    <td colspan="2"><div align="center">Pesquisa | Nova pesquisa</div></td>
  </tr>
</table>
<br />
<table width="643" border="1" align="center">
  <tr>
    <td class="style2"><div align="center"><a href="Incluircli.php"> Incluir</a> | </div>
    <td class="style2"><div align="center"><a href="Exibircli.php"> Exibir</a> | </div>
    <td class="style2"><div align="center"><a href="Alterarcli.phpr "> Alterar</a> | </div>
    <td class="style2"><div align="center"><a href="Excluircli.php"> Excluir </a> | </div>
    <td class="style2"><div align="center"><a href="Imprimircli.php"> Imprimir </a> | </div>
    <td class="style2"><div align="center"><a href="Cadastro.php"> Tela de Cadastro</a> | </div>
    <td class="style2"><div align="center"><a href="inicio.php">Menu inicial </a> | </div>
    <td class="style2"><div align="center"><a href="inicio.php">Sair do Sistema </a> | </div>
    
    
    </td>
  </tr>
</table>
<p align="center" class="style2">&nbsp;</p>
<form action="<?php echo $editFormAction; ?>" method="post" name="form1" id="form1">
  <table width="790" border="1" align="center" bordercolor="#FF0000">
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Codigo: 
        <input type="text" name="Codmat" value="" size="32" /></td>
      <td>Descricao:
      <input type="text" name="Descricao" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">Unidade:
        <input type="text" name="Unidade" value="" size="32" />
      </div></td>
      <td>Codigo Letra:
      <input type="text" name="Codlt" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">Vl. Unit.
        <input type="text" name="Vunit" value="" size="32" />
      </div></td>
      <td>Vl Unit2:
      <input type="text" name="Vunit2" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">Vl. Unit3:
        <input type="text" name="Vunit3" value="" size="32" />
      </div></td>
      <td>Vl. Unit4:
      <input type="text" name="Vunit4" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">Vl. Unit5:
        <input type="text" name="Vunit5" value="" size="32" />
      </div></td>
      <td>Vl. Unit6:
      <input type="text" name="Vunit6" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">Dias_comp:
        <input type="text" name="Dias_comp" value="" size="32" />
      </div></td>
      <td>Vl. Minimo:
      <input type="text" name="Vlminimo" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">IPI:
        <input type="text" name="IPI" value="" size="32" />
      </div></td>
      <td>EAN:
      <input type="text" name="Ean" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">Estmin:
        <input type="text" name="Estmin" value="" size="32" />
      </div></td>
      <td>Peso br:
      <input type="text" name="Pesobr" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">Cadastro:
        <input type="text" name="Data" value="" size="32" />
      </div></td>
      <td>Alteração:
      <input type="text" name="Dataalt" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"><div align="left">Datalt2:
        <input type="text" name="Datalt2" value="" size="32" />
      </div></td>
      <td>Data2:
      <input type="text" name="Data2" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td colspan="2" align="right" nowrap="nowrap"><div align="center">
        <input type="submit" value="Gravar" />
      </div></td>
    </tr>
  </table>
  <input type="hidden" name="MM_insert" value="form1" />
</form>
<p>&nbsp;</p>
</body>
</html>
