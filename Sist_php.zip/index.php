<?PHP error_reporting(0); ?>
<?PHP   session_start(); ?>
<?PHP 
$_SESSION['cntip'] = 1; // TIPO DE ACESSO 1 LOCAL E 2 ACESSO REMOTO
IF ($_SESSION['cntip'] == 2) {
   //
   // pula essas linha quando remoto pq gera mensagem de erro
   //
   session_start(); 
   error_reporting(0);
} 
 ?>
<?PHP 
if ($_SESSION['cntip'] == 1) {
   $_SESSION['con1'] = 'local';
   $_SESSION['con2'] = '\classes\conexao_opera.php';  
   }// acesso local 
else {
   $_SESSION['con1'] = 'remoto';
   // troquei em 280114     $_SESSION['con2'] = '/home/sistemanfe.com/central/classes/conexao_opera.php'; 
   $_SESSION['con2'] = '../central/classes/conexao_opera.php';
   //echo 'opcao 2';
}
?>

<html>
<head>
<title>Sistema Central</title>
<link href="estilos2.css" rel="stylesheet" type="text/css">
</head><body>
<?php 
$inicio  = time();
$_SESSION['usuario'] = 'nome usuario'; //usuario 
$_SESSION['inicio']  = 'data-hora inicio'; //inicio  
$_SESSION['nivel']   = 'nivel de operacao'; //nivel  
$_SESSION['pc']      = 'nome ip pc'; //nome pc 
$_SESSION['versao']      = '1.1'; //nome pc 

?>
<?php require_once('cabecalho.php'); ?>
<div id="container">
  <div id="menu_esquerdo">
                <hr>
                <center>         
               <a href="index.php?pagina=link1" class="link1"><span>Orcamento</span></a> 
                | <a href="index.php?pagina=link2" class="link2"><span>NF-e</span></a> 
                | <a href="financeiro.php" class="link3"><span>Financeiro</span></a> 
                | <a href="relatorios.php" class="link4"><span>Relatorios</span></a> 
                | <a href="cadastro.php">Cadastros e Tabelas</a>
				| <a href="configuracao.php" class="link6"><span>Configuracoes </span></a>
				</center> <BR>
      </div>
      <div id="caixa">
      <?php
	  //if (isset($_GET['pagina'])) {
      //    echo "Essa variavel existe.<BR>";} 
	  //echo $_GET['pagina'];
	  
      if($_GET['pagina'] == 'link1') {
	    include "0001/mostra_dados.php";         }
      elseif($_GET['pagina'] == 'link2')  {
        include "pag/link2.php";         }
      elseif($_GET['pagina'] == 'link3')  {
 	    include "pag/link3.php";         } 
      elseif($_GET['pagina'] == 'link4')   {
	    include "pag/link4.php"; } 
      elseif($_GET['pagina'] == 'link5')   {
	    include "pag/link5.php"; } 
     elseif($_GET['pagina'] == 'link6')   {
	    echo "include 'pag/link6.php'"; } 
						
      else  { 
	    include "pag/link1.php";         }
		
      ?>   
   </div>  
   <div id="rodape"> 
     
    </div>
</div>
</body>
</html>