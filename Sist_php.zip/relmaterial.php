<?php
require('connections/cn_central.php');
class material {

   public function _construct(){
           $this->conn = new cn_central.php();
		   }
		   
   public function artistas () {
            //$sql = "select * from material order by codmat asc";
			$sql = "select * from material";
			$this->rs = mysql_db_query(this->conn->centrabanco,$sql);
			}





]


?>