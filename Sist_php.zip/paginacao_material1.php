<?php 
include('include/paginacao1.php');
$obj = new artistas(); 
$obj->selecionar();
$obj->paginacao('20');
echo "<h2 align=center>Lista do Cadastro de Materiais </h2>";
echo "<center><table border=1 >";
		echo "<tr><td>"."Codigo"."<td>"."         Descri�ao do Produto                "."<td>"."Unid."."<td>"." VL. Unitario  "."</tr>";	
while($linha= mysql_fetch_object($obj->rs)){ 
		//echo $linha->DESCRICAO."</br>";	
		echo "<tr><td>".$linha->CODMAT."<td>".$linha->DESCRICAO." ".$linha->DESCRICA2."<td>".$linha->UNIDADE."<td>"."R$ ".number_format($linha->VUNIT,2,',','.')."</tr>";	
	
}
echo "</table></center>";
echo "<br><center>";
$obj->pagfirst();
$obj->pagprev();
$obj->paginar();
$obj->pagnext();
$obj->paglast();
echo "</center>";
?>'