<?php require_once('Connections/cn_central.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO nfopera (CODOPE, OPERACAO, TIPO, ESTOQUE, OPEABRE) VALUES (%s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['CODOPE'], "text"),
                       GetSQLValueString($_POST['OPERACAO'], "text"),
                       GetSQLValueString($_POST['TIPO'], "text"),
                       GetSQLValueString($_POST['ESTOQUE'], "text"),
                       GetSQLValueString($_POST['OPEABRE'], "text"));

  mysql_select_db($database_cn_central, $cn_central);
  $Result1 = mysql_query($insertSQL, $cn_central) or die(mysql_error());

  $insertGoTo = "sucesso_nfopera.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style2 {color: #000000}
-->
</style>
</head>

<body>
<h2 align="center" class="style2">Cadastro de Natureza de Operaçao de NF</h2>
<table width="200" border="1" align="center">
  <tr>
    <td class="style2"><a href="inicio.php">Página inicial</a> | Finalizar</td>
  </tr>
</table>
<p class="style2">&nbsp;</p>

<form action="<?php echo $editFormAction; ?>" method="post" name="form1" class="style2" id="form1">
  <table align="center">
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Código:</td>
      <td><input type="text" name="CODOPE" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Descrição:</td>
      <td><input type="text" name="OPERACAO" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">TIPO:</td>
      <td><input type="text" name="TIPO" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Calc.Estoque:</td>
      <td><input type="text" name="ESTOQUE" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Código de CFOP</td>
      <td><input type="text" name="OPEABRE" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">&nbsp;</td>
      <td><input type="submit" value="Salvar" /></td>
    </tr>
  </table>
  <input type="hidden" name="MM_insert" value="form1" />
</form>
<p class="style2">&nbsp;</p>
</body>
</html>
