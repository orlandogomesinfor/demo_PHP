<?php session_start(); ?>
<html>
<body>
<?php //include('../cabecalho.php');  ?>
<p>
<?php
$campo0= $_POST ['txtcampo0'];
$campo1= $_POST ['txtcampo1'];
$campo2= $_POST ['txtcampo2'];
$campo3= $_POST ['txtcampo3'];
$campo4= $_POST ['txtcampo4'];
$campo5= $_POST ['txtcampo5'];
$codigo= $_POST ['codigo'];
if ($_SESSION['cntip']==2){
//if ($cntip==2) {
   $servidor="localhost";
   $login="root";
   $senha="";
   $banco="bdcentral"; 
   $tabela="test_prefixtabicms";
   $conexao = mysql_connect($servidor,$login,$senha);
}
else
{
   $banco='central1';
   $tabela='test_prefixtabicms';
   $conexao = mysql_connect ("mysql18.redehost.com.br","usuariorcentral","usuariocentral");
}

if (!$conexao) {
	die('Conexao nao Efeutada Falha: ' . mysql_error());  }
$banco_ok = mysql_select_db($banco,$conexao);  // mysql 5.0 
if (!$banco_ok) {
	 die ('Erro na abertura de banco de dados: ' . mysql_error());   }

$altera="UPDATE $tabela SET SIGLA='$campo0',ESTADO='$campo1', PERCENTUAL='$campo2', MARGEM='$campo3', PERC_MARG='$campo4',CALCSIT='$campo5' WHERE id='$codigo'";
//echo "<br> $altera <br>";	
	mysql_query($altera,$conexao) or die ("ocorreu algum erro!!! $codigo xxxxxx");
echo "<center> Dados gravados com sucesso...</center>";
?>
</p>
<p><center><a href="../cadastro.php">Tela de Cadastro Geral</a> | <a href="../cadastro.php?pagina=link7" class="link7">Exibe consulta</a></center></p>
<?php include('../rodape.php'); ?>
</body>
</html>