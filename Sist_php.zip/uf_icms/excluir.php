<?php
include('../cabecalho.php');
$bancox='central1';
$tabelax='test_prefixtabicms';
$conexao = mysql_connect ("mysql18.redehost.com.br","usuariorcentral","usuariocentral");
if (!$conexao) {
	die('Conexao nao Efeutada Falha: ' . mysql_error());  }
$banco_ok = mysql_select_db($bancox,$conexao);  // mysql 5.0 
if (!$banco_ok) {
	 die ('Erro na abertura de banco de dados: ' . mysql_error());   }
$quem=$_GET['quem'];
$exclui = "delete from $tabelax where id='$quem'";
$resux=mysql_query ($exclui,$conexao);
echo "<center>";
if ($resux==1) {
     echo "<BR><h2>Registro excluido com sucesso...<br></h2>"; 
	 }
	 else 	 {
	 echo "Erro!!!, registro n�o pode ser excluido.";	 }

	 echo "<br><a href='../cadastro.php'><span>Tela de Cadastro Geral</span></a> | ";
	 echo "<A HREF='../cadastro.php?pagina=link7' class='link7''>Exibe consulta</A></center><BR><BR>";
// header('location: index.php');
include('../rodape.php');
?>
