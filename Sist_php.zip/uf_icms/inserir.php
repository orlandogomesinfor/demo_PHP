<?php if (!isset($_SESSION)) { session_start();}
	//require($_SESSION['con1']);
	$_SESSION['con1']='..\classes\conexao_opera.php';
	require($_SESSION['con1']);
	$conexao = new conexao();
	$cone = mysql_connect($conexao->servidor,$conexao->login,$conexao->senha);
	$tabela = 'test_prefixtabicms';
?>
<!-- Rotinas em JS -->
<script>function formata() {  document.getElementById("PERCENTUAL").value += ",00";}</script>
<?PHP
 //Verifica se o botão submit foi carregado
if($_SERVER['REQUEST_METHOD'] == 'POST'){ 
	   //Espefica campos foram todos preenchidos;
	   $val = array('SIGLA', 'ESTADO','MARGEM');
	   $erros = array(); 
	   $N_Campo=0;
	   foreach($val as $campo){
		  if(empty($_POST["$campo"])){
			 $N_Campo=$N_Campo+1;
			 $erros[$campo] = TRUE;}
	   }
	   if(empty($erros)){
		  //Continua se todos os campos estao ok
		  if (!$cone) {
			 die('Conexao nao Efeutada Operação Cancelada... ' . mysql_error());}
		  
		  $banco_ok = mysql_select_db($conexao->banco,$cone); 
		 // $banco_ok = mysql_select_db($conexao->banco,$cone); 
		$incluir = "insert into ".$tabela." (SIGLA,ESTADO,PERCENTUAL,MARGEM,PERC_MARG,CALCSIT) values ('".$_POST['SIGLA']."','".$_POST['ESTADO']."','".$_POST['PERCENTUAL']."','".$_POST['MARGEM']."','".$_POST['PERC_MARG']."','".$_POST['CALCSIT']."')";   
		// linha ok		$incluir = "insert into ".$tabela." (SIGLA,ESTADO) values ('".$_POST['SIGLA']."','".$_POST['ESTADO']."')";   
 
		  mysql_query ($incluir) or die ("ocorreu algum erro!!!");
		 // echo "<A href='cadastro.php?pagina=link7'>Gravacao bem sucedida, click para continuar...</A>";
		//echo "TESTE 1 <BR>";
		header("location: http://localhost/central/uf_icms/cadastro_sucesso.php/");
		//header("location: http://localhost/central/uf_icms/cadastro_sucesso.php");
    	//echo "TESTE 2 <BR>";
		 // echo " http://localhost/central/cadastro.php?pagina=link7.</A>";
		//  exit();
	   } 
	   else {
		  echo "Detectado(s) ".$N_Campo ." Campo(s) obrigatorio nao preenchido(s), digite novamente e click no Botão >>INSERIR <<"; 
	   }
	 }
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>

<script language="javascript">
  function veri1()
    {
	   /*alert(" Inicio de Teste!"); */
         if (form1.SIGLA.value=="") {
             alert("Por favor, Digite uma sigla!");
			 form1.SIGLA.focus();
			 return false;
			 }
         
    }
</script>
<script language="javascript">
   function veri2()
    {
	   /*alert(" Inicio de Teste!"); 
		 if (form1.ESTADO.value=="") {
             alert("Por favor, Digite a UF!"); 
			 form1.ESTADO.focus();
			 return false;
			 }
         */
    }
</script>
	
<script language="javascript">
 function veri3()
    {*/ 
	 alert(" Inicio de Teste!"); 
		 			 
		 if (form1.CALCSIT.value=="") {
             alert("Por favor, Digite: -- > S=sim ou N=nao  ");
			 form1.CALCSIT.focus();
			 return false;
			  }*/
	         
    }
</script>


</head>

<body>
<?php include('../cabecalho.php'); ?>
<h2 align="center">Cadastro de UF e ICMS </h2>
<p align="center"><a href="../cadastro.php">Cadastro Geral de tabelas</a> | 
<?php echo "<a href='../cadastro.php?pagina=link7' class='link7'><span>Exibe consulta</span></a></center>"; ?></p>
<p align="center">&nbsp;</p>

<form name="form1" method="post"   action="inserir.php">
  <table align="center">
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">SIGLA:</td>
      <td><input type="text" name="SIGLA" value="" size="32"  onblur='veri1()' /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Estado:</td>
      <td><input type="text" name="ESTADO" value="" size="32"  onblur='veri2()' /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">% ICMS:</td>
      <td><input type="text" name="PERCENTUAL" value=""  maxlength="5" size="5" onblur="formata();" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">MARGEM:</td>
      <td><input type="text" name="MARGEM" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">% de Margem:</td>
      <td><input type="text" name="PERC_MARG" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Calcula (S/N):</td>
      <td><input type="text" name="CALCSIT" value="" size="32"  onblur='veri3()' /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">&nbsp;</td>
      <td><input type="submit" value="Inserir" /></td>
    </tr>
  </table>
  
</form>
<p>&nbsp;</p>
<?php include('../rodape.php')?>
</body>
</html>
