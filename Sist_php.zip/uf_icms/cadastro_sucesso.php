<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php include('../cabecalho.php'); ?>
<h2 align="center">Operacao Realizado com Sucesso</h2>
<p align="center"><a href='/central/cadastro.php' >Exibir a tela de consuta Cadastro </a> | <a href="../inserir.php">Cadastrar novo Item</a></p>
<!--BR /><BR /><p align="center"><a href="'../mostra_dados.php'">Exibir a tela de consuta</a> | <a href="inserir.php">Cadastrar novo Item</a></p>
< ? php echo "<a href='/central/cadastro.php'><span> xxxxxxxxx Exibe consulta</span></a></center>"; ?></p -->


<p>&nbsp;</p>
<p>&nbsp;</p>
<?php include('../rodape.php');?>
</body>
</html>
