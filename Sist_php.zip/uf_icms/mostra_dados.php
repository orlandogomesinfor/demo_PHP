<?PHP if (!isset($_SESSION)) { session_start(); } 
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php 
include('includes/classes/pag_manu001.php');
$obj = new artistas(); 
$ordem=2;
$obj->selecionar($ordem);
$obj->paginacao('20');
?>
<?php
echo "<center>";
$obj->pagfirst();
$obj->pagprev();
$obj->paginar();
$obj->pagnext();
$obj->paglast();
echo "</center>";
echo "<center><table border=0 >";
		echo "<tr bgColor='#CCCCCC'><td>"."UF"."<td align='center'>"."Estado"."<td>"." % ICMS "."<td>"."Margem"."<td>"."% Margem".    "<td>"."Cal. Sit. Trib. "."<td>"."Editar"."<td>Excluir"."</tr>";	
		$tamfont=3;
		$volta=1;
		$cortab='#ffffff';
while($linha= mysql_fetch_object($obj->rs)){ 
			echo "<tr bgcolor='$cortab'><td><font size='$tamfont'>".$linha->SIGLA."</font><td><font size='$tamfont'>".$linha->ESTADO."</font> <td align='center'><font size='$tamfont'>".number_format($linha->PERCENTUAL,2,',','.')."</font>"."<td align='center'><font size='$tamfont'>".number_format($linha->MARGEM,2,',','.')."</font>"."<td align='center'><font size='$tamfont'>".number_format($linha->PERC_MARG,2,',','.')."</font>"."<td align='center' ><font size='$tamfont'>".$linha->CALCSIT."</font>"."<td align='center'><A HREF='./uf_icms/form_altera_dados.php?quem=$linha->id'><img src='imagem/editar.jpg' height='28' width='32'></a>"."<td align='center'>"."<A HREF='uf_icms/excluir.php?quem=$linha->id'><img src='imagem/lixeira.png' height='22' width='22'></A>"."</tr>";	
	if ($volta==1) {
		$cortab='#ffffcc';
		$volta=0;}
	else {
	   $cortab='#ffffff';
		$volta=$volta+1;		
	}
}
echo "</table></center>";
echo "</font>";

 ?>

