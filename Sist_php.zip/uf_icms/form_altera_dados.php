<?php
session_start(); 
if ($_SESSION['cntip']==2) {
   $servidor="localhost";
   $login="root";
   $senha="";
   $banco="bdcentral"; 
   $tabela="test_prefixtabicms";
   $conexao = mysql_connect($servidor,$login,$senha);
}
else
{
   $banco='central1';
   $tabela='test_prefixtabicms';
   $conexao = mysql_connect ("mysql18.redehost.com.br","usuariorcentral","usuariocentral");
}

if (!$conexao) {
	die('Conexao nao Efeutada Falha: ' . mysql_error());  }
$banco_ok = mysql_select_db($banco,$conexao);  // mysql 5.0 
if (!$banco_ok) {
	 die ('Erro na abertura de banco de dados: ' . mysql_error());   }
 

$quem=$_GET['quem'];
$consulta = "select * from $tabela where id='$quem' ";
$resultado =mysql_query ($consulta,$conexao);
$linha = mysql_fetch_row ($resultado);
include('../cabecalho.php'); 
//<?php require_once('../cabecalho.php');
?>

<center>Altera��o de Dados</center>
<center><a href="../cadastro.php">Tela de Cadastro Geral</a> | <a href="../cadastro.php?pagina=link7" class="link7">Exibe consulta</a></center>
<br />
<form name="form" method="post" action="altera_dados.php">
  <table width="428" border="0" align="center">
    <tr>
      <td width="138">UF:</td>
      <td width="274"><input name="txtcampo0" type="text" id= "txtcampo0" size="40" value="<?php echo $linha[0];?>" ReadOnly="True" /></td>
    </tr>
    <tr>
      <td>Estado: </td>
      <td><input name="txtcampo1" type="text" id= "txtcampo1" size="40" value="<?php echo $linha[1];?>" /></td>
    </tr>
    <tr>
      <td>% ICMS:</td>
      <td><input name="txtcampo2" type="text" id= "txtcampo2" size="40" value="<?php echo $linha[2];?>" /></td>
    </tr>
    
    <tr>
      <td>Margem (MVA):</td>
      <td><input name="txtcampo3" type="text" id= "txtcampo3" size="40" value="<?php echo $linha[3];?>" /></td>
    </tr> 
        <tr>
      <td>% da Margem:</td>
      <td><input name="txtcampo4" type="text" id= "txtcampo4" size="40" value="<?php echo $linha[4];?>" /></td>
    </tr>
    
     <tr>
      <td>Calc. Situa&ccedil;&atilde;o (s/n):</td>
      <td><input name="txtcampo5" type="text" id= "txtcampo5" size="40" value="<?php echo $linha[5];?>" /></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><div align="center">
        <input type ="submit" name="submit" value="Salvar" />
        <input name="reset" type="reset" id="reset" value="limpar" />
      </div></td>
    </tr>
  </table>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p><BR>
    <BR>
    <input type="hidden" name="codigo" value="<?php echo $linha[6];?>">
<BR>
  </p>
<?php include('../rodape.php'); ?>
</form>
