<?php 
//require('classes/conexao_opera.php');
$idx = "asas" ; //$_GET['quem'];
$idxx = $_GET['quem'];
echo $idx."<BR>";
echo $idxx."<BR>";


	$servidor="mysql18.redehost.com.br";
	$login="usuariorcentral";
	$senha="usuariocentral";
	$banco="central1";
		
		//public function conexao(){
	//		mysql_connect($this->servidor,$this->login,$this->senha);	
		//}
				
    $conexao = mysql_connect ($servidor,$login,$senha);
	mysql_select_db ($banco,$conexao);

    //$quem=$_GET['quem'];
    $exclui = "select from cliente1 where id='$idxx'";
	 
	//mysql_query ($exclui,$conexao) or die ("Ocorreu algum erro!!!");

    echo $exclui;


 /* rotina abaixao tirar*

<html>
<body>
<?
$conexao = mysql_connect ("localhost","root","");
	   mysql_select_db ("loja",$conexao);

$quem=$_GET['quem'];
$exclui = "delete from cliente1 where codigo='$quem'";
	 
	mysql_query ($exclui,$conexao) or die ("Ocorreu algum erro!!!");



*/
?>