<NotepadPlus>
    <Session activeView="0">
        <mainView activeIndex="5">
            <File firstVisibleLine="51" xOffset="0" scrollWidth="1248" startPos="1458" endPos="1458" selMode="0" lang="PHP" encoding="-1" filename="C:\wamp\www\central\0001\conpedido.php" />
            <File firstVisibleLine="51" xOffset="0" scrollWidth="2272" startPos="919" endPos="919" selMode="0" lang="PHP" encoding="-1" filename="C:\wamp\www\central\0001\mostra_dados.php" />
            <File firstVisibleLine="42" xOffset="0" scrollWidth="1384" startPos="2649" endPos="2648" selMode="0" lang="PHP" encoding="-1" filename="C:\wamp\www\central\0001\includes\classes\pag_manu001.php" />
            <File firstVisibleLine="0" xOffset="0" scrollWidth="1755" startPos="0" endPos="0" selMode="0" lang="PHP" encoding="-1" filename="C:\wamp\www\central\uf_icms\includes\classes\pag_manu001.php" />
            <File firstVisibleLine="0" xOffset="0" scrollWidth="768" startPos="0" endPos="0" selMode="0" lang="HTML" encoding="-1" filename="C:\wamp\www\central\danfe\form.html" />
        </mainView>
        <subView activeIndex="0" />
    </Session>
</NotepadPlus>
