<?
require_once('libs/ToolsNFePHP.class.php');
require_once("config/config.php");
require_once('libs/DanfeNFePHP.class.php');

//$arq = $_GET['nfe'];
$nfe = new ToolsNFePHP;
$arq = $nfe->aprDir.'35100400225574000168550010000000294368689157-nfe.xml';


if (is_file($arq)){
    $docxml = file_get_contents($arq);
        $danfe = new DanfeNFePHP($docxml, 'P',
'A4','images/logo.jpg','I','');
    $id = $danfe->montaDANFE();
    $teste = $danfe->printDANFE($id.'.pdf','I');
}

?>
