<script src="DWConfiguration/ActiveContent/IncludeFiles/AC_RunActiveContent.js" type="text/javascript"></script>
<script src="SpryAssets/SpryMenuBar.js" type="text/javascript"></script>
<link href="SpryAssets/SpryMenuBarHorizontal.css" rel="stylesheet" type="text/css" />

<table width="950" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#FF0000">
<tr>
<td width="19%"> Logo </td>
<td width="53%"> <div align="center">Menu - Banner </div></td>
<td width="28%"> <div align="left">Vers&atilde;o: 1x.xx Usuario: NomeUser</div><BR /><center>Suporte</center></td>
</tr>
<tr>
</table>
<table width="223" align="center">
  <td width="215" Aling="center">
    <div align="center">Inicio | Trocar Usuario | Sair </div></td>
</table>
 
<table width="600" border="1" align="center">
  <tr>
    <td>
      
      <ul id="MenuBar1" class="MenuBarHorizontal">
        <li><a class="MenuBarItemSubmenu" href="#">Cadastros</a>
          <ul>
            <li><a href="#">Materiais</a></li>
              <li><a href="#">Clientes</a></li>
              <li><a href="#">Representantes</a></li>
          </ul>
        </li>
          <li><a href="#" class="MenuBarItemSubmenu">Relatorios</a>
            <ul>
              <li><a href="#paginacao_material1.php">Material</a></li>
              <li><a href="paginacao_requis.php">Lista de Requisi&ccedil;&atilde;o</a></li>
            </ul>
          </li>
          <li><a class="MenuBarItemSubmenu" href="#">Lan&ccedil;amentos</a>
            <ul>
              <li><a class="MenuBarItemSubmenu" href="#">N&atilde;o disponivel</a>
                <ul>
                  <li><a href="#">Item 3.1.1</a></li>
                  <li><a href="#">Item 3.1.2</a></li>
                </ul>
              </li>
              <li><a href="#">N&atilde;o disponivel</a></li>
            </ul>
          </li>
          <li><a href="#">NF-e</a></li>
    </ul></td>
  </tr>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p>

<script type="text/javascript">
<!--
var MenuBar1 = new Spry.Widget.MenuBar("MenuBar1", {imgDown:"SpryAssets/SpryMenuBarDownHover.gif", imgRight:"SpryAssets/SpryMenuBarRightHover.gif"});
//-->
</script>
