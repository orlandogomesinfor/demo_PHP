<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php //include "include/php/menu_principal.php"; ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<script src="SpryAssets/SpryMenuBar.js" type="text/javascript"></script>
<link href="SpryAssets/SpryMenuBarHorizontal.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryMenuBarVertical.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	background-image: url(imagem/pl_fundo2.png);
}
-->
</style></head>

<body>
<table width="200" border="1" align="center" bordercolor="#FF0000">
  <tr>
    <td><p>&nbsp;</p>
    <p>&nbsp;</p></td>
  </tr>
  <tr>
    <td><div align="center">Sistema de Gestão Empresarial </div></td>
  </tr>
  <tr>
    <td><p align="center"><a href="cadastro.php">Mautençao e tabelas</a> | Lançamentos |Relatórios | Ferramentas | Configuração</p>
    <p>&nbsp;</p></td>
  </tr>
  <tr>
    <td><table width="886" border="1" align="center" bordercolor="#0000FF">
      <tr>
        <td><ul id="MenuBar1" class="MenuBarHorizontal">
            <li><a class="MenuBarItemSubmenu" href="#">Orcamento</a>
                <ul>
                  <li><a href="#">Novo</a></li>
                  <li><a href="#">Consulta</a></li>
                  <li><a href="#">Excluir</a></li>
                  <li><a href="#">Exibir</a></li>
                </ul>
            </li>
          <li><a href="#" class="MenuBarItemSubmenu">NF-e</a>
                <ul>
                  <li><a href="#">Novo</a></li>
                  <li><a href="#">Untitled Item</a></li>
                </ul>
          </li>
          <li><a class="MenuBarItemSubmenu" href="#">Financeiro</a>
                <ul>
                  <li><a class="MenuBarItemSubmenu" href="#">Item 3.1</a>
                      <ul>
                        <li><a href="#">Item 3.1.1</a></li>
                        <li><a href="#">Item 3.1.2</a></li>
                      </ul>
                  </li>
                  <li><a href="#">Item 3.2</a></li>
                  <li><a href="#">Item 3.3</a></li>
                </ul>
          </li>
          <li><a href="#">Relatorios</a></li>
          <li><a href="#" class="MenuBarItemSubmenu">Tabelas</a>
                <ul>
                  <li><a href="cmaterial.php">Material</a></li>
                  <li><a href="#">Cliente</a></li>
                  <li><a href="#">Transportadora</a></li>
                  <li><a href="#">Grupo Material</a></li>
                  <li><a href="#">CFOP</a></li>
                  <li><a href="#">ICMS</a></li>
                  <li><a href="#">Representante</a></li>
                </ul>
          </li>
          <li><a href="#">Ferramentas</a></li>
        </ul>
            <p>&nbsp;</p>
          <p>&nbsp;</p></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="103"><p>&nbsp;</p>
    <p>&nbsp;</p></td>
  </tr>
</table>
<p>&nbsp;</p>
<script type="text/javascript">
<!--

var MenuBar1 = new Spry.Widget.MenuBar("MenuBar1", {imgDown:"SpryAssets/SpryMenuBarDownHover.gif", imgRight:"SpryAssets/SpryMenuBarRightHover.gif"});

//-->
</script>
</body>

</html>
