<?php header('Content-Type: text/html; charset=ISO-8859-1'); ?>
<!-- cabecalho -->
<div id="cabecalho"> <table width="100%" border="1" cellspacing="0" cellpadding="0">
  <tr>
    <td width="24%"> SISTEMA<BR />
    <?php  if (!isset($_SESSION)) { session_start(); }
	  if ($_SESSION['cntip'] == 1) {
	   echo "Acesso: <font color='Green'> Local</font>"; 
	   }
	   else { 
	   echo "Acesso: <Font Color='Blue'>Remoto</Font>";
	   } ;
	   ?> 
	   </td>
    <td width="43%"><center>
      SISTEMA CENTRAL
    </center></td>
    <td width="33%">
    <center>
       Vers&atilde;o: <?PHP echo $_SESSION['versao'] ?> | Usuario: Padrao<br> 
    <!-- a href="index.php?pagina=link1" class="link1"><span>inicio</span></a> | <a href="index.php?pagina=link2" class="link2"><span>troca usuario</span></a --> 
	<a href="/central/index.php">Tela Principal</a> | <a href="index.php?pagina=link2" class="link2"><span>Trocar usuario</span></a --> 
	| <a href="index.php"><span>Sair</span></a> </center>
    <!-- | <a href="index.php?pagina=link1" class="link1"><span>Sair</span></a> </center> -->
    </td>
  </tr>
 </table>


   </div>
  
