-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 22-Ago-2022 às 05:04
-- Versão do servidor: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bdcentral`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tabicms`
--

CREATE TABLE IF NOT EXISTS `tabicms` (
  `SIGLA` varchar(2) DEFAULT NULL,
  `ESTADO` varchar(30) DEFAULT NULL,
  `PERCENTUAL` double DEFAULT NULL,
  `MARGEM` double DEFAULT NULL,
  `PERC_MARG` double DEFAULT NULL,
  `CALCSIT` varchar(1) DEFAULT NULL,
  `SMARGEM` double DEFAULT NULL,
  `SPERC_MARG` double DEFAULT NULL,
  `SCALCSIT` varchar(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tabicms`
--

INSERT INTO `tabicms` (`SIGLA`, `ESTADO`, `PERCENTUAL`, `MARGEM`, `PERC_MARG`, `CALCSIT`, `SMARGEM`, `SPERC_MARG`, `SCALCSIT`) VALUES
('SP', 'SAO PAULO', 18, 65.94, 18, 'N', 65.94, 18, 'N'),
('RJ', 'RIO DE JANEIRO', 12, 88.96, 20, 'N', 71.78, 20, 'N'),
('RS', 'RIO GRANDE DO SUL', 12, 71.28, 18, 'N', 59.6, 18, 'N'),
('MG', 'MINAS GERAIS', 12, 84.35, 18, 'N', 71.78, 18, 'N'),
('SC', 'SANTA CATARINA', 12, 82.13, 17, 'N', 71.78, 17, 'N'),
('DF', 'DISTRITO FEDERAL', 7, 94.82, 18, 'N', 71.78, 18, 'N'),
('GO', 'GOIAS', 7, 92.48, 17, 'N', 71.78, 17, 'N'),
('MT', 'MATO GROSSO', 7, 14.5, 17, 'N', 40, 17, 'N'),
('MS', 'MATO GROSSO DO SUL', 7, 0, 0, 'N', 0, 0, 'N'),
('PR', 'PARAN?', 12, 84.35, 18, 'N', 71.78, 18, 'N'),
('BA', 'BAHIA', 7, 94.82, 18, 'N', 71.78, 18, 'N'),
('PE', 'PERNAMBUCO', 7, 94.82, 18, 'N', 71.78, 18, 'N'),
('PA', 'PARA', 7, 92.48, 17, 'N', 71.78, 17, 'N'),
('MA', 'MARANH?O', 7, 94.82, 18, 'N', 71.78, 18, 'N'),
('PI', 'PIAU?', 7, 94.82, 18, 'N', 71.78, 18, 'N'),
('AC', 'ACRE', 7, 92.48, 17, 'N', 71.78, 17, 'N'),
('AL', 'ALAGOAS', 7, 94.82, 18, 'N', 71.78, 18, 'N'),
('AP', 'AMAP?', 7, 94.82, 18, 'N', 71.78, 18, 'N'),
('AM', 'AMAZONAS', 7, 94.82, 18, 'N', 71.78, 18, 'N'),
('CE', 'CEAR?', 7, 40, 18, 'N', 40, 18, 'N'),
('ES', 'ESP?RITO SANTO', 7, 92.48, 17, 'N', 71.78, 17, 'N'),
('PB', 'PARA?BA', 7, 94.82, 18, 'N', 71.78, 18, 'N'),
('RN', 'RIO GRANDE DO NORTE', 7, 0, 0, 'N', 0, 0, 'N'),
('RO', 'RONDONIA', 7, 0, 0, 'N', 0, 0, 'N'),
('RR', 'RORAIMA', 7, 92.48, 17, 'N', 71.78, 17, 'N'),
('SE', 'SERGIPE', 7, 0, 0, 'N', 0, 0, 'N'),
('TO', 'TOCANTINS', 7, 0, 0, 'N', 0, 0, 'N'),
('EX', 'sem s.t', 7, 0, 0, 'N', 0, 0, 'N'),
('AX', 'nao usa mais desde 9/10/13', 7, 78.83, 17, 'N', 0, 0, 'N'),
('E2', 'sem st icms 18', 18, 0, 0, 'N', 0, 0, 'N'),
('M2', 'nao usa desde 09/10/13', 12, 71.28, 18, 'N', 0, 0, 'N'),
('R2', 'nao usa mais desde 09/10', 12, 73.39, 19, 'N', 0, 0, 'N'),
('SU', 'nao usa desde 09/10/13', 12, 69.21, 17, 'N', 0, 0, 'N'),
('G2', 'GOIAS', 7, 78.83, 12, 'N', 0, 0, 'N'),
('E1', 'sem st. icms 12', 12, 0, 0, 'N', 0, 0, 'N'),
('D1', 'nao usa mais desde 9/10/13', 7, 56.9, 17, 'N', 0, 0, 'N'),
('E3', 'sem s.t', 0, 0, 0, 'N', 0, 0, 'N');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
